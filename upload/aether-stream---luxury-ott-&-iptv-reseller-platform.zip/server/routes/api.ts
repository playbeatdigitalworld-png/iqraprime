/**
 * Aether Stream Master API Router
 * Secure backend API handling authentication, streaming content delivery,
 * Star IPTV reseller operations, subscription management, and takedown procedures.
 */

import { Router, type Request, type Response } from 'express';
import { db } from '../db/store.js';
import { starIptvProvider } from '../starIptvProvider.js';
import type { Channel, Movie, User } from '../../src/types/index.js';

export const apiRouter = Router();

// ==========================================
// 1. AUTHENTICATION & PILOT ACCESS GATE
// ==========================================

apiRouter.get('/pilot/settings', (_req: Request, res: Response) => {
  db.recalculatePilotSlots();
  res.json({ settings: db.pilotSettings });
});

apiRouter.post('/pilot/settings', (req: Request, res: Response) => {
  const { maxPrivateUsers, maxDevicesPerUser, privateMode } = req.body;
  if (maxPrivateUsers !== undefined) {
    db.pilotSettings.maxPrivateUsers = Math.max(1, Number(maxPrivateUsers));
  }
  if (maxDevicesPerUser !== undefined) {
    db.pilotSettings.maxDevicesPerUser = Math.max(1, Number(maxDevicesPerUser));
  }
  if (privateMode !== undefined) {
    db.pilotSettings.privateMode = Boolean(privateMode);
  }
  db.recalculatePilotSlots();
  db.logAdminAction('PILOT_SETTINGS_UPDATE', `Pilot settings updated: maxUsers=${db.pilotSettings.maxPrivateUsers}, maxDevices=${db.pilotSettings.maxDevicesPerUser}`);
  res.json({ success: true, settings: db.pilotSettings });
});

apiRouter.post('/auth/login', (req: Request, res: Response) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required.' });
  }

  const storedPassword = db.userPasswords.get(email.toLowerCase().trim());
  const user = Array.from(db.users.values()).find(
    (u) => u.email.toLowerCase() === email.toLowerCase().trim()
  );

  if (!user || storedPassword !== password) {
    return res.status(401).json({ error: 'Invalid email or password.' });
  }

  // Check if member is disabled
  const status = db.userStatus.get(user.id) || 'active';
  if (status === 'disabled') {
    return res.status(403).json({
      error: 'Your private pilot member account has been suspended or disabled by the administrator.',
    });
  }

  // Retrieve user subscription
  const subscription = db.subscriptions.get(user.id);

  // Manage device session limit (maxDevicesPerUser)
  let userDevices = db.devices.get(user.id) || [];
  const maxDev = db.pilotSettings.maxDevicesPerUser || 2;
  const currentBrowser = req.headers['user-agent']?.includes('Mobile') ? 'Mobile Device' : 'Desktop Browser';

  // Check if current device exists, else add
  const hasCurrent = userDevices.some((d) => d.isCurrent);
  if (!hasCurrent) {
    const newDev = {
      id: `dev-${Date.now().toString(36)}`,
      name: `${user.name.split(' ')[0]}'s ${currentBrowser}`,
      deviceType: req.headers['user-agent']?.includes('Mobile') ? ('mobile' as const) : ('desktop' as const),
      browser: currentBrowser,
      os: 'Online Client',
      lastActive: 'Just now',
      isCurrent: true,
    };
    if (userDevices.length >= maxDev) {
      // Prune oldest non-current device to respect device limit
      userDevices = userDevices.slice(0, maxDev - 1);
    }
    userDevices.unshift(newDev);
    db.devices.set(user.id, userDevices);
  }

  res.json({
    success: true,
    user,
    subscription,
    token: `aether_token_${user.id}_${Date.now()}`,
  });
});

apiRouter.post('/auth/register', (req: Request, res: Response) => {
  // Check if public registration is disabled for Private Pilot mode
  if (!db.pilotSettings.publicRegistration) {
    return res.status(403).json({
      error: 'Public registration is disabled. This is a private closed-beta platform for approved household members only. Please contact the administrator to be invited.',
    });
  }

  const { name, email, password } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ error: 'Name, email, and password are required.' });
  }

  const result = db.createMember(name, email, password);
  if (!result.success) {
    return res.status(400).json({ error: result.error });
  }

  const user = db.users.get(result.member!.id)!;
  const subscription = db.subscriptions.get(user.id);

  res.status(201).json({
    success: true,
    user,
    subscription,
    token: `aether_token_${user.id}_${Date.now()}`,
  });
});

apiRouter.get('/auth/me', (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  // Fallback to customer or admin if mock token passed
  let userId = 'usr-customer-01';
  if (authHeader && authHeader.includes('usr-admin')) {
    userId = 'usr-admin-01';
  } else if (authHeader && authHeader.startsWith('Bearer aether_token_')) {
    const parts = authHeader.split('_');
    if (parts.length >= 3 && db.users.has(parts[2])) {
      userId = parts[2];
    }
  }

  const user = db.users.get(userId);
  if (!user) {
    return res.status(404).json({ error: 'Session not found.' });
  }

  const subscription = db.subscriptions.get(user.id);
  res.json({ user, subscription });
});

// ==========================================
// 2. CONTENT STREAMS & MEDIA (FREE & VERIFIED)
// ==========================================

apiRouter.get('/content/channels', (_req: Request, res: Response) => {
  const verifiedChannels = Array.from(db.channels.values()).filter((c) => c.enabled);
  const m3uChannels = starIptvProvider.getEnabledChannelsAsContent();
  res.json({ channels: [...verifiedChannels, ...m3uChannels] });
});

apiRouter.get('/content/channels/:id', (req: Request, res: Response) => {
  const channel = db.channels.get(req.params.id) || starIptvProvider.getEnabledChannelsAsContent().find((c) => c.id === req.params.id);
  if (!channel || !channel.enabled) {
    return res.status(404).json({ error: 'Channel not found or currently unavailable.' });
  }
  res.json({ channel });
});

apiRouter.get('/content/movies', (_req: Request, res: Response) => {
  const movies = Array.from(db.movies.values()).filter((m) => m.enabled);
  res.json({ movies });
});

apiRouter.get('/content/movies/:id', (req: Request, res: Response) => {
  const movie = db.movies.get(req.params.id);
  if (!movie || !movie.enabled) {
    return res.status(404).json({ error: 'Movie not found or currently unavailable.' });
  }
  res.json({ movie });
});

// Watchlist & Progress
apiRouter.get('/content/watchlist', (req: Request, res: Response) => {
  const userId = (req.query.userId as string) || 'usr-customer-01';
  const itemIds = db.watchlist.get(userId) || new Set<string>();

  const items = Array.from(itemIds).map((id) => {
    if (id.startsWith('ch-')) return { type: 'channel', data: db.channels.get(id) };
    return { type: 'movie', data: db.movies.get(id) };
  }).filter((i) => i.data && i.data.enabled);

  res.json({ watchlist: items });
});

apiRouter.post('/content/watchlist/toggle', (req: Request, res: Response) => {
  const { contentId, userId = 'usr-customer-01' } = req.body;
  if (!contentId) return res.status(400).json({ error: 'contentId is required.' });

  let list = db.watchlist.get(userId);
  if (!list) {
    list = new Set<string>();
    db.watchlist.set(userId, list);
  }

  let inList = false;
  if (list.has(contentId)) {
    list.delete(contentId);
    inList = false;
  } else {
    list.add(contentId);
    inList = true;
  }

  res.json({ success: true, inList, contentId });
});

apiRouter.get('/content/continue-watching', (req: Request, res: Response) => {
  const userId = (req.query.userId as string) || 'usr-customer-01';
  const historyMap = db.watchHistory.get(userId);
  const items = historyMap ? Array.from(historyMap.values()).sort(
    (a, b) => new Date(b.lastWatchedAt).getTime() - new Date(a.lastWatchedAt).getTime()
  ) : [];

  res.json({ continueWatching: items });
});

apiRouter.post('/content/progress', (req: Request, res: Response) => {
  const { contentId, contentType, positionSeconds, durationSeconds, userId = 'usr-customer-01' } = req.body;
  if (!contentId) return res.status(400).json({ error: 'Missing contentId' });

  let userHist = db.watchHistory.get(userId);
  if (!userHist) {
    userHist = new Map();
    db.watchHistory.set(userId, userHist);
  }

  const title = contentId.startsWith('ch-')
    ? db.channels.get(contentId)?.channelName || 'Live Channel'
    : db.movies.get(contentId)?.title || 'Movie';

  const poster = contentId.startsWith('ch-')
    ? db.channels.get(contentId)?.logo || ''
    : db.movies.get(contentId)?.poster || '';

  const completed = positionSeconds > 0 && durationSeconds > 0 && positionSeconds / durationSeconds > 0.92;

  userHist.set(contentId, {
    contentId,
    contentType: contentType || (contentId.startsWith('ch-') ? 'channel' : 'movie'),
    positionSeconds: Math.floor(positionSeconds || 0),
    durationSeconds: Math.floor(durationSeconds || 0),
    completed,
    lastWatchedAt: new Date().toISOString(),
    title,
    poster,
  });

  res.json({ success: true });
});

// ==========================================
// 3. SUBSCRIPTIONS & PLANS
// ==========================================

apiRouter.get('/subscriptions/plans', async (_req: Request, res: Response) => {
  const starPackagesResult = await starIptvProvider.getPackages();

  const plans = [
    {
      id: 'plan-free',
      tier: 'free',
      name: 'Cinema Explorer',
      price: '$0',
      period: 'Forever Free',
      description: 'Full access to verified public-domain cinema, open-source animated films, and free-to-air international news broadcasts.',
      features: [
        'Curated Public Domain Cinema',
        'Open-Source Film Projects',
        'Official Free-to-Air Public Broadcasters',
        'Standard Definition & HD Streaming',
        'Universal Watchlist & History',
        'Installable PWA for Mobile & TV',
      ],
      isPopular: false,
      ctaText: 'Stream Free Now',
      iptvIncluded: false,
    },
    {
      id: 'plan-cinema-vip',
      tier: 'premium',
      name: 'Aether Cinephile VIP',
      price: '$8.99',
      period: 'per month',
      description: 'Enhanced cinematic experience with 4K UHD restoration streaming, zero ads, priority CDN routing, and multiple device profiles.',
      features: [
        'Everything in Free Explorer',
        'Full 4K UHD Restored Master Feeds',
        'Multi-Screen Household Streaming (3 Devices)',
        'Enhanced 7-Day Catchup EPG Guide',
        'Personalized Recommendation Rail',
        'Zero Ad Banners or Pre-rolls',
      ],
      isPopular: true,
      ctaText: 'Activate Cinephile VIP',
      iptvIncluded: false,
    },
    {
      id: 'plan-star-iptv',
      tier: 'iptv_vip',
      name: 'Star IPTV Reseller Pass',
      price: '$14.99',
      period: 'per month',
      description: 'Authorized Star IPTV reseller line integration with worldwide premium channels, live sporting feeds, and personal M3U/EPG line credentials.',
      features: [
        'Authorized Star IPTV Reseller Line Provisioning',
        'Personal Masked M3U Plus & XMLTV Credentials',
        'Full High-Bitrate FHD/4K Live Sports Feeds',
        'Dedicated Connection Allocation',
        'Device Management & MAC Sync',
        'Direct Reseller Concierge Support',
      ],
      isPopular: false,
      ctaText: 'Subscribe via Star IPTV',
      iptvIncluded: true,
      availablePackages: starPackagesResult.packages,
    },
  ];

  res.json({ plans });
});

apiRouter.get('/subscriptions/my-subscription', (req: Request, res: Response) => {
  const userId = (req.query.userId as string) || 'usr-customer-01';
  const sub = db.subscriptions.get(userId) || {
    id: 'sub-none',
    userId,
    tier: 'free',
    status: 'active',
    packageName: 'Free Explorer',
    activationDate: new Date().toISOString(),
    expiryDate: '2099-12-31T23:59:59.000Z',
    maxDevices: 1,
    activeDevices: 1,
    autoRenew: false,
  };
  const devices = db.devices.get(userId) || [];

  res.json({ subscription: sub, devices });
});

apiRouter.post('/subscriptions/order', async (req: Request, res: Response) => {
  const { planId, packageId, paymentMethod, email, name, userId = 'usr-customer-01' } = req.body;

  if (planId === 'plan-star-iptv') {
    // Invoke Star IPTV adapter
    const iptvOrder = await starIptvProvider.createCustomer({
      name: name || 'Valued Subscriber',
      email: email || 'subscriber@aetherstream.tv',
      note: `Package: ${packageId || 'star-pkg-1m'} via ${paymentMethod || 'Manual Bank / Gateway'}`,
    });

    // Update customer subscription to Star IPTV line
    const updatedSub = {
      id: `sub-star-${Date.now().toString(36)}`,
      userId,
      tier: 'iptv_vip' as const,
      status: 'active' as const,
      packageName: 'Star IPTV VIP Executive Line',
      activationDate: new Date().toISOString(),
      expiryDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      maxDevices: 2,
      activeDevices: 1,
      autoRenew: true,
      iptvCredentials: {
        username: `star_${userId.slice(-6)}`,
        serverHost: 'vip.stariptv.pk',
        m3uUrlMasked: 'http://vip.stariptv.pk:8080/get.php?username=star_••••••&password=••••••••&type=m3u_plus',
        epgUrl: 'http://vip.stariptv.pk:8080/xmltv.php?username=star_••••••&password=••••••••',
      },
    };
    db.subscriptions.set(userId, updatedSub);

    return res.json({
      success: true,
      subscription: updatedSub,
      starIptvResult: iptvOrder,
      message: 'Subscription created. Reseller panel notification queued for line issuance.',
    });
  }

  // Cinephile pass upgrade
  const vipSub = {
    id: `sub-prem-${Date.now().toString(36)}`,
    userId,
    tier: 'premium' as const,
    status: 'active' as const,
    packageName: 'Aether Cinephile VIP',
    activationDate: new Date().toISOString(),
    expiryDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
    maxDevices: 3,
    activeDevices: 1,
    autoRenew: true,
  };
  db.subscriptions.set(userId, vipSub);

  res.json({ success: true, subscription: vipSub, message: 'VIP Subscription activated successfully!' });
});

// ==========================================
// 4. PRIVATE MEMBER MANAGEMENT (3–5 MEMBERS)
// ==========================================

apiRouter.get('/admin/members', (_req: Request, res: Response) => {
  const members = db.getMembers();
  res.json({
    members,
    slots: {
      total: db.pilotSettings.maxPrivateUsers,
      current: db.users.size,
      active: db.pilotSettings.activeMembers,
      remaining: db.pilotSettings.remainingSlots,
      maxDevicesPerUser: db.pilotSettings.maxDevicesPerUser,
    },
  });
});

apiRouter.post('/admin/members/create', (req: Request, res: Response) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ error: 'Name, email, and password are required.' });
  }

  const result = db.createMember(name, email, password);
  if (!result.success) {
    return res.status(400).json({ error: result.error });
  }

  res.status(201).json(result);
});

apiRouter.post('/admin/members/:id/toggle', (req: Request, res: Response) => {
  const result = db.toggleMemberStatus(req.params.id);
  if (!result.success) {
    return res.status(400).json({ error: result.error });
  }
  res.json(result);
});

apiRouter.delete('/admin/members/:id', (req: Request, res: Response) => {
  const result = db.deleteMember(req.params.id);
  if (!result.success) {
    return res.status(400).json({ error: result.error });
  }
  res.json({ success: true, message: 'Member deleted from private pilot.' });
});

apiRouter.post('/admin/members/:id/reset-password', (req: Request, res: Response) => {
  const { password } = req.body;
  if (!password) return res.status(400).json({ error: 'New password is required.' });
  const result = db.resetMemberPassword(req.params.id, password);
  if (!result.success) return res.status(400).json({ error: result.error });
  res.json({ success: true, message: 'Password reset successfully.' });
});

apiRouter.post('/devices/revoke', (req: Request, res: Response) => {
  const { userId, deviceId } = req.body;
  if (!userId || !deviceId) {
    return res.status(400).json({ error: 'userId and deviceId are required.' });
  }
  db.revokeDevice(userId, deviceId);
  const updated = db.devices.get(userId) || [];
  res.json({ success: true, devices: updated, message: 'Device revoked successfully.' });
});

apiRouter.get('/admin/devices', (_req: Request, res: Response) => {
  const devices = db.getAllDevices();
  res.json({ devices, total: devices.length });
});

apiRouter.get('/admin/watch-history', (_req: Request, res: Response) => {
  const history = db.getAllWatchHistory();
  res.json({ history, total: history.length });
});

// ==========================================
// 5. STAR IPTV RESELLER VAULT & M3U IMPORTER
// ==========================================

apiRouter.get('/iptv/config', (_req: Request, res: Response) => {
  const summary = starIptvProvider.getConfigSummary();
  const logs = starIptvProvider.getLogs();
  res.json({
    config: summary,
    logs,
  });
});

apiRouter.post('/iptv/config', (req: Request, res: Response) => {
  const { providerName, serverUrl, username, password, m3uUrl, epgUrl, apiUrl, apiKey, resellerId } = req.body;
  starIptvProvider.updateConfig({
    providerName,
    serverUrl,
    username,
    password,
    m3uUrl,
    epgUrl,
    apiUrl,
    apiKey,
    resellerId,
  });

  db.logAdminAction('IPTV_VAULT_UPDATE', `Star IPTV credentials vault updated by admin.`);
  res.json({
    success: true,
    message: 'Star IPTV vault credentials secured in server-side storage.',
    config: starIptvProvider.getConfigSummary(),
  });
});

apiRouter.post('/iptv/test-connection', async (_req: Request, res: Response) => {
  const result = await starIptvProvider.testConnection();
  db.logAdminAction('IPTV_TEST_SERVER', `Star IPTV connection test: ${result.status} (${result.message})`);
  res.json(result);
});

apiRouter.post('/iptv/test-m3u', async (req: Request, res: Response) => {
  const { url } = req.body;
  const result = await starIptvProvider.testM3U(url);
  db.logAdminAction('IPTV_TEST_M3U', `M3U URL test: ${result.status} (${result.message})`);
  res.json(result);
});

apiRouter.post('/iptv/test-epg', async (req: Request, res: Response) => {
  const { url } = req.body;
  const result = await starIptvProvider.testEPG(url);
  db.logAdminAction('IPTV_TEST_EPG', `EPG URL test: ${result.status} (${result.message})`);
  res.json(result);
});

apiRouter.post('/iptv/import-m3u', async (req: Request, res: Response) => {
  const { url } = req.body;
  const result = await starIptvProvider.fetchAndImportM3U(url);
  if (result.success) {
    db.logAdminAction('IPTV_IMPORT_M3U', `Imported ${result.count} channels from M3U playlist.`);
  }
  res.json(result);
});

apiRouter.get('/iptv/categories', async (_req: Request, res: Response) => {
  const categories = await starIptvProvider.getCategories();
  res.json({ categories, total: categories.length });
});

apiRouter.post('/iptv/import-category', async (req: Request, res: Response) => {
  const { categoryId } = req.body;
  if (!categoryId) {
    return res.status(400).json({ error: 'categoryId is required' });
  }
  const result = await starIptvProvider.importCategory(String(categoryId));
  if (result.success) {
    db.logAdminAction('IPTV_IMPORT_CATEGORY', `Imported ${result.count} HLS channels from category "${result.categoryName}".`);
  }
  res.json(result);
});

apiRouter.get('/iptv/m3u-channels', (_req: Request, res: Response) => {
  const channels = starIptvProvider.getParsedChannels();
  res.json({ channels, total: channels.length });
});

apiRouter.post('/iptv/m3u-channels/:id/toggle', (req: Request, res: Response) => {
  const { id } = req.params;
  const { enabled } = req.body;
  const ok = starIptvProvider.toggleChannelEnabled(id, enabled);
  if (!ok) return res.status(404).json({ error: 'M3U Channel not found' });
  res.json({ success: true, channelId: id, enabled });
});

apiRouter.post('/iptv/m3u-channels/bulk', (req: Request, res: Response) => {
  const { enabled, group } = req.body;
  const result = starIptvProvider.bulkToggleChannels(Boolean(enabled), group);
  db.logAdminAction('IPTV_BULK_TOGGLE', `Bulk updated ${result.count} channels (enabled=${enabled})`);
  res.json({ success: true, ...result });
});

apiRouter.get('/iptv/packages', async (_req: Request, res: Response) => {
  const result = await starIptvProvider.getPackages();
  res.json(result);
});

apiRouter.get('/iptv/logs', (_req: Request, res: Response) => {
  res.json({ logs: starIptvProvider.getLogs() });
});

// ==========================================
// 5. ADMIN CONTROL & CONTENT MANAGEMENT
// ==========================================

apiRouter.get('/admin/stats', (_req: Request, res: Response) => {
  const stats = db.getAdminStats();
  const logs = db.adminLogs.slice(0, 30);
  res.json({ stats, logs });
});

apiRouter.get('/admin/channels', (_req: Request, res: Response) => {
  const channels = Array.from(db.channels.values());
  res.json({ channels });
});

apiRouter.post('/admin/channels/toggle', (req: Request, res: Response) => {
  const { channelId, enabled } = req.body;
  const channel = db.channels.get(channelId);
  if (!channel) return res.status(404).json({ error: 'Channel not found' });

  channel.enabled = enabled !== undefined ? enabled : !channel.enabled;
  db.channels.set(channelId, channel);

  db.logAdminAction('CHANNEL_TOGGLE', `Channel ${channel.channelName} (${channelId}) enabled state set to ${channel.enabled}`);
  res.json({ success: true, channel });
});

apiRouter.post('/admin/channels/add', (req: Request, res: Response) => {
  const newChan: Channel = req.body;
  if (!newChan.id || !newChan.channelName || !newChan.streamUrl) {
    return res.status(400).json({ error: 'id, channelName, and streamUrl are required.' });
  }

  db.channels.set(newChan.id, {
    ...newChan,
    lastVerified: new Date().toISOString(),
    enabled: true,
  });

  db.logAdminAction('CHANNEL_ADD', `Added new channel: ${newChan.channelName} (${newChan.rightsStatus})`);
  res.json({ success: true, channel: db.channels.get(newChan.id) });
});

apiRouter.get('/admin/movies', (_req: Request, res: Response) => {
  const movies = Array.from(db.movies.values());
  res.json({ movies });
});

apiRouter.post('/admin/movies/toggle', (req: Request, res: Response) => {
  const { movieId, enabled } = req.body;
  const movie = db.movies.get(movieId);
  if (!movie) return res.status(404).json({ error: 'Movie not found' });

  movie.enabled = enabled !== undefined ? enabled : !movie.enabled;
  db.movies.set(movieId, movie);

  db.logAdminAction('MOVIE_TOGGLE', `Movie ${movie.title} (${movieId}) enabled state set to ${movie.enabled}`);
  res.json({ success: true, movie });
});

apiRouter.post('/admin/movies/add', (req: Request, res: Response) => {
  const newMovie: Movie = req.body;
  if (!newMovie.id || !newMovie.title || !newMovie.source) {
    return res.status(400).json({ error: 'id, title, and source are required.' });
  }

  db.movies.set(newMovie.id, {
    ...newMovie,
    enabled: true,
  });

  db.logAdminAction('MOVIE_ADD', `Added new movie: ${newMovie.title} (${newMovie.rightsStatus})`);
  res.json({ success: true, movie: db.movies.get(newMovie.id) });
});

// ==========================================
// 6. COPYRIGHT, TAKEDOWN & DMCA PROCEDURES
// ==========================================

apiRouter.post('/takedown/submit', (req: Request, res: Response) => {
  const {
    contentId,
    contentTitle,
    claimantName,
    claimantEmail,
    copyrightOwner,
    allegedInfringementUrl,
    statement,
  } = req.body;

  if (!claimantName || !claimantEmail || !statement || (!contentId && !allegedInfringementUrl)) {
    return res.status(400).json({ error: 'Please provide claimant details, infringement URL/content, and sworn statement.' });
  }

  const requestId = `tk-${Date.now().toString(36)}`;
  const takedown: typeof db.takedownRequests[0] = {
    id: requestId,
    contentId: contentId || 'URL_REFERENCE',
    contentTitle: contentTitle || allegedInfringementUrl,
    claimantName,
    claimantEmail,
    copyrightOwner: copyrightOwner || claimantName,
    allegedInfringementUrl: allegedInfringementUrl || `https://aetherstream.tv/content/${contentId}`,
    statement,
    status: 'PENDING',
    createdAt: new Date().toISOString(),
    notes: 'Submitted via public copyright notice portal. Queued for immediate officer triage.',
  };

  db.takedownRequests.unshift(takedown);
  db.logAdminAction('TAKEDOWN_SUBMITTED', `Copyright report logged [${requestId}] for ${takedown.contentTitle} by ${claimantName}`);

  res.status(201).json({
    success: true,
    ticketNumber: requestId,
    message: 'Your report has been logged with the Aether Stream compliance office. Our automated system has notified the admin team for immediate audit.',
  });
});

apiRouter.get('/admin/takedowns', (_req: Request, res: Response) => {
  res.json({ takedowns: db.takedownRequests });
});

apiRouter.post('/admin/takedowns/:id/action', (req: Request, res: Response) => {
  const { id } = req.params;
  const { action, notes } = req.body; // action: 'DISABLE_AND_ACCEPT' | 'REJECT' | 'UNDER_REVIEW'

  const request = db.takedownRequests.find((t) => t.id === id);
  if (!request) return res.status(404).json({ error: 'Takedown record not found' });

  if (action === 'DISABLE_AND_ACCEPT') {
    request.status = 'ACCEPTED_REMOVED';
    request.reviewedAt = new Date().toISOString();
    request.notes = notes || 'Content disabled and confirmed removed pursuant to takedown claim.';

    // Automatically disable if contentId matches
    if (db.channels.has(request.contentId)) {
      const ch = db.channels.get(request.contentId)!;
      ch.enabled = false;
      db.channels.set(request.contentId, ch);
    }
    if (db.movies.has(request.contentId)) {
      const m = db.movies.get(request.contentId)!;
      m.enabled = false;
      db.movies.set(request.contentId, m);
    }
    db.logAdminAction('TAKEDOWN_ACCEPTED', `Content removed and takedown ${id} marked accepted.`);
  } else if (action === 'REJECT') {
    request.status = 'REJECTED';
    request.reviewedAt = new Date().toISOString();
    request.notes = notes || 'Claim reviewed; content verified as public domain or authorized open broadcast.';
    db.logAdminAction('TAKEDOWN_REJECTED', `Takedown ${id} rejected following rights audit.`);
  } else {
    request.status = 'UNDER_REVIEW';
    request.notes = notes || 'Under ongoing legal review.';
  }

  res.json({ success: true, takedown: request });
});

apiRouter.get('/health', (_req: Request, res: Response) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptimeSeconds: process.uptime(),
    channelsCount: db.channels.size,
    moviesCount: db.movies.size,
    usersCount: db.users.size,
  });
});
