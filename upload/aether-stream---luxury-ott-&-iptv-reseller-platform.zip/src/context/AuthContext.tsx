import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import type { Subscription, User } from '../types/index.js';
import { supabase } from '../services/supabase.js';
import { useToast } from './ToastContext.js';

interface AuthContextType {
  user: User | null;
  subscription: Subscription | null;
  status: 'active' | 'pending' | 'disabled' | null;
  isLoading: boolean;
  isAdmin: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  register: (name: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [status, setStatus] = useState<'active' | 'pending' | 'disabled' | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { showToast } = useToast();

  const loadUserContext = useCallback(async (userId: string) => {
    try {
      const { data: profile } = await supabase.from('profiles').select('*').eq('id', userId).single();
      const { data: member } = await supabase.from('private_members').select('status').eq('user_id', userId).single();
      const { data: sub } = await supabase.from('subscriptions').select('*').eq('user_id', userId).single();

      if (profile) {
        setUser({
          id: profile.id,
          email: profile.email,
          name: profile.name,
          role: profile.role,
          avatarUrl: profile.avatar_url,
          createdAt: profile.created_at,
        });
        setStatus(member?.status || 'pending');
        setSubscription(sub);
      }
    } catch (err) {
      console.error('Context load error:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        loadUserContext(session.user.id);
      } else {
        setIsLoading(false);
      }
    });

    const { data: { subscription: authSubscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        loadUserContext(session.user.id);
      } else {
        setUser(null);
        setSubscription(null);
        setStatus(null);
        setIsLoading(false);
      }
    });

    return () => authSubscription.unsubscribe();
  }, [loadUserContext]);

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
      showToast(`Welcome!`, 'success');
      return true;
    } catch (err: any) {
      showToast(err.message || 'Login failed', 'error');
      return false;
    }
  };

  const register = async (name: string, email: string, password: string): Promise<boolean> => {
    try {
      const { data, error } = await supabase.auth.signUp({ email, password, options: { data: { name } } });
      if (error) throw error;
      if (data.user) {
        await supabase.from('profiles').insert([{ id: data.user.id, email, name, role: 'member' }]);
        await supabase.from('private_members').insert([{ user_id: data.user.id, email, name, status: 'pending' }]);
      }
      showToast(`Account requested. Please wait for admin approval.`, 'success');
      return true;
    } catch (err: any) {
      showToast(err.message || 'Registration failed', 'error');
      return false;
    }
  };

  const logout = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setSubscription(null);
    setStatus(null);
    showToast('Signed out', 'info');
  };

  const isAdmin = user?.role === 'admin';

  return (
    <AuthContext.Provider
      value={{
        user,
        subscription,
        status,
        isLoading,
        isAdmin,
        login,
        register,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};
