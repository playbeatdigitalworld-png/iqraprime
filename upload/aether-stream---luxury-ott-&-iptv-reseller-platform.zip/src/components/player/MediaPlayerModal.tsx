import React, { useEffect, useRef, useState, useCallback } from 'react';
import Hls from 'hls.js';
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  Minimize,
  RotateCcw,
  RotateCw,
  X,
  Radio,
  Tv,
  Subtitles,
  AlertTriangle,
  RefreshCw,
  Sliders,
  List,
  ChevronRight,
  Music,
  Check,
  Search,
} from 'lucide-react';
import type { Channel, Movie } from '../../types/index.js';
import { useWatchlist } from '../../context/WatchlistContext.js';
import { LegalBadge } from '../common/LegalBadge.js';

interface MediaPlayerModalProps {
  movie?: Movie;
  channel?: Channel;
  mode: 'full' | 'trailer';
  startPosition?: number;
  onClose: () => void;
  onNextChannel?: () => void;
  onPrevChannel?: () => void;
  channels?: Channel[];
  onSelectChannel?: (channel: Channel) => void;
}

export const MediaPlayerModal: React.FC<MediaPlayerModalProps> = ({
  movie,
  channel,
  mode,
  startPosition = 0,
  onClose,
  onNextChannel,
  onPrevChannel,
  channels = [],
  onSelectChannel,
}) => {
  const { recordProgress } = useWatchlist();
  const videoRef = useRef<HTMLVideoElement>(null);
  const hlsRef = useRef<Hls | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.85);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [controlsVisible, setControlsVisible] = useState(true);
  const controlsTimeoutRef = useRef<number | null>(null);

  // Stream status badge
  const [streamStatus, setStreamStatus] = useState<'live' | 'reconnecting' | 'offline'>('live');

  // Quality levels
  const [qualities, setQualities] = useState<Array<{ id: number; name: string }>>([]);
  const [currentQuality, setCurrentQuality] = useState<number>(-1); // -1 = Auto
  const [showQualityMenu, setShowQualityMenu] = useState(false);

  // Audio tracks
  const [audioTracks, setAudioTracks] = useState<Array<{ id: number; name: string }>>([]);
  const [currentAudioTrack, setCurrentAudioTrack] = useState<number>(0);
  const [showAudioMenu, setShowAudioMenu] = useState(false);

  // Channel switcher drawer inside player
  const [showDrawer, setShowDrawer] = useState(false);
  const [drawerSearch, setDrawerSearch] = useState('');

  const [subtitlesEnabled, setSubtitlesEnabled] = useState(true);

  const isLive = Boolean(channel);
  const mediaTitle = channel ? channel.channelName : movie ? movie.title : 'Aether Stream Player';
  const rawStreamUrl = channel
    ? channel.streamUrl
    : mode === 'trailer'
    ? movie?.trailerUrl
    : movie?.videoUrl || movie?.trailerUrl;

  const effectiveStreamUrl = rawStreamUrl || '';

  // Initialize playback with HLS or Native Video
  const loadStream = useCallback(() => {
    const video = videoRef.current;
    if (!video || !effectiveStreamUrl) {
      setIsLoading(false);
      setErrorMessage('No authorized stream source found for this title.');
      setStreamStatus('offline');
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);
    setStreamStatus(isLive ? 'live' : 'live');

    // Destroy existing Hls instance if any
    if (hlsRef.current) {
      hlsRef.current.destroy();
      hlsRef.current = null;
    }

    const isHlsSource = effectiveStreamUrl.includes('.m3u8') || effectiveStreamUrl.includes('manifest');

    if (isHlsSource && Hls.isSupported()) {
      const hls = new Hls({
        enableWorker: true,
        lowLatencyMode: true,
        backBufferLength: 60,
      });
      hlsRef.current = hls;

      hls.loadSource(effectiveStreamUrl);
      hls.attachMedia(video);

      hls.on(Hls.Events.MANIFEST_PARSED, (_event, data) => {
        setIsLoading(false);
        setStreamStatus('live');
        const levels = data.levels.map((lvl, index) => ({
          id: index,
          name: `${lvl.height || 720}p`,
        }));
        setQualities([{ id: -1, name: 'Auto' }, ...levels]);

        // Audio tracks
        if (hls.audioTracks && hls.audioTracks.length > 0) {
          setAudioTracks(
            hls.audioTracks.map((t, idx) => ({
              id: idx,
              name: t.name || t.lang || `Track ${idx + 1}`,
            }))
          );
        }

        if (startPosition > 0 && !isLive) {
          video.currentTime = startPosition;
        }

        video.play().catch(() => {
          setIsPlaying(false);
        });
      });

      hls.on(Hls.Events.AUDIO_TRACKS_UPDATED, (_event, data) => {
        if (data.audioTracks && data.audioTracks.length > 0) {
          setAudioTracks(
            data.audioTracks.map((t, idx) => ({
              id: idx,
              name: t.name || t.lang || `Track ${idx + 1}`,
            }))
          );
        }
      });

      hls.on(Hls.Events.ERROR, (_event, data) => {
        if (data.fatal) {
          switch (data.type) {
            case Hls.ErrorTypes.NETWORK_ERROR:
              setStreamStatus('reconnecting');
              setErrorMessage('Network connection lost or stream source unreachable. Attempting auto-reconnect.');
              hls.startLoad();
              break;
            case Hls.ErrorTypes.MEDIA_ERROR:
              setStreamStatus('reconnecting');
              setErrorMessage('Encountered media decoding error. Recovering media...');
              hls.recoverMediaError();
              break;
            default:
              setStreamStatus('offline');
              setErrorMessage('Stream playback failed. The broadcaster feed may be currently off-air or unavailable.');
              hls.destroy();
              break;
          }
        }
      });
    } else {
      // Direct MP4 or Native Safari HLS
      video.src = effectiveStreamUrl;
      video.load();

      video.onloadedmetadata = () => {
        setIsLoading(false);
        setStreamStatus('live');
        if (startPosition > 0 && !isLive) {
          video.currentTime = startPosition;
        }
        video.play().catch(() => setIsPlaying(false));
      };

      video.onerror = () => {
        setIsLoading(false);
        setStreamStatus('offline');
        setErrorMessage('Failed to decode media source. Please verify stream status.');
      };
    }
  }, [effectiveStreamUrl, isLive, startPosition]);

  useEffect(() => {
    loadStream();
    return () => {
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
    };
  }, [loadStream]);

  // Sync Video state listeners
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const onPlay = () => {
      setIsPlaying(true);
      setStreamStatus('live');
    };
    const onPause = () => setIsPlaying(false);
    const onWaiting = () => {
      setIsLoading(true);
      setStreamStatus('reconnecting');
    };
    const onPlaying = () => {
      setIsLoading(false);
      setStreamStatus('live');
    };
    const onTimeUpdate = () => {
      setCurrentTime(video.currentTime);
      if (!isLive && movie) {
        recordProgress(movie.id, video.currentTime, video.duration || 1);
      }
    };
    const onDurationChange = () => setDuration(video.duration || 0);

    video.addEventListener('play', onPlay);
    video.addEventListener('pause', onPause);
    video.addEventListener('waiting', onWaiting);
    video.addEventListener('playing', onPlaying);
    video.addEventListener('timeupdate', onTimeUpdate);
    video.addEventListener('durationchange', onDurationChange);

    return () => {
      video.removeEventListener('play', onPlay);
      video.removeEventListener('pause', onPause);
      video.removeEventListener('waiting', onWaiting);
      video.removeEventListener('playing', onPlaying);
      video.removeEventListener('timeupdate', onTimeUpdate);
      video.removeEventListener('durationchange', onDurationChange);
    };
  }, [isLive, movie, recordProgress]);

  // Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;

      const video = videoRef.current;
      if (!video) return;

      switch (e.key) {
        case ' ':
        case 'k':
          e.preventDefault();
          if (video.paused) video.play();
          else video.pause();
          break;
        case 'ArrowLeft':
          e.preventDefault();
          video.currentTime = Math.max(0, video.currentTime - 10);
          break;
        case 'ArrowRight':
          e.preventDefault();
          video.currentTime = Math.min(video.duration || 0, video.currentTime + 10);
          break;
        case 'f':
          e.preventDefault();
          toggleFullscreen();
          break;
        case 'm':
          e.preventDefault();
          toggleMute();
          break;
        case 'Escape':
          e.preventDefault();
          if (showDrawer) {
            setShowDrawer(false);
          } else {
            onClose();
          }
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose, showDrawer]);

  // Controls Visibility Timer
  const handleMouseMove = () => {
    setControlsVisible(true);
    if (controlsTimeoutRef.current) window.clearTimeout(controlsTimeoutRef.current);
    controlsTimeoutRef.current = window.setTimeout(() => {
      if (isPlaying && !showDrawer && !showQualityMenu && !showAudioMenu) {
        setControlsVisible(false);
      }
    }, 3500);
  };

  const togglePlay = () => {
    const video = videoRef.current;
    if (!video) return;
    if (video.paused) video.play();
    else video.pause();
  };

  const toggleMute = () => {
    const video = videoRef.current;
    if (!video) return;
    video.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  const handleVolumeChange = (newVol: number) => {
    const video = videoRef.current;
    if (!video) return;
    video.volume = newVol;
    setVolume(newVol);
    if (newVol === 0) {
      video.muted = true;
      setIsMuted(true);
    } else if (isMuted) {
      video.muted = false;
      setIsMuted(false);
    }
  };

  const handleSeek = (seconds: number) => {
    const video = videoRef.current;
    if (!video) return;
    video.currentTime = seconds;
    setCurrentTime(seconds);
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  const formatTime = (secs: number) => {
    if (isNaN(secs)) return '0:00';
    const h = Math.floor(secs / 3600);
    const m = Math.floor((secs % 3600) / 60);
    const s = Math.floor(secs % 60);
    if (h > 0) return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  const handleQualitySelect = (qualityId: number) => {
    if (hlsRef.current) {
      hlsRef.current.currentLevel = qualityId;
      setCurrentQuality(qualityId);
      setShowQualityMenu(false);
    }
  };

  const handleAudioTrackSelect = (trackId: number) => {
    if (hlsRef.current) {
      hlsRef.current.audioTrack = trackId;
      setCurrentAudioTrack(trackId);
      setShowAudioMenu(false);
    }
  };

  // Filter channels for drawer
  const drawerFilteredChannels = channels.filter((c) =>
    c.channelName.toLowerCase().includes(drawerSearch.toLowerCase()) ||
    c.category.toLowerCase().includes(drawerSearch.toLowerCase())
  );

  return (
    <div
      ref={containerRef}
      onMouseMove={handleMouseMove}
      className="fixed inset-0 z-50 bg-black flex items-center justify-center select-none overflow-hidden"
    >
      {/* Video Element */}
      <video
        ref={videoRef}
        className="w-full h-full object-contain cursor-pointer"
        onClick={togglePlay}
        playsInline
      />

      {/* Buffering Indicator */}
      {isLoading && !errorMessage && (
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none bg-black/40 backdrop-blur-[2px]">
          <div className="w-12 h-12 rounded-full border-2 border-white/20 border-t-[#E5093A] animate-spin" />
          <span className="mt-4 text-xs font-medium text-slate-300 tracking-wider font-display">
            Buffering master feed...
          </span>
        </div>
      )}

      {/* Stream Error Overlay */}
      {errorMessage && (
        <div className="absolute inset-0 z-30 flex flex-col items-center justify-center p-6 bg-[#05070B]/90 text-center">
          <div className="w-14 h-14 rounded-2xl bg-[#E5093A]/10 border border-[#E5093A]/30 flex items-center justify-center mb-4">
            <AlertTriangle className="w-7 h-7 text-[#E5093A]" />
          </div>
          <h3 className="text-lg font-bold text-white mb-2 font-display">Playback Interrupted</h3>
          <p className="text-xs text-slate-300 max-w-md leading-relaxed mb-6">{errorMessage}</p>
          <div className="flex items-center gap-3">
            <button
              onClick={loadStream}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#E5093A] hover:bg-[#B90732] text-white text-xs font-semibold shadow-lg transition-transform active:scale-95"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Retry Stream</span>
            </button>
            <button
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-slate-200 text-xs font-semibold transition-colors"
            >
              Exit Player
            </button>
          </div>
        </div>
      )}

      {/* Top Header Bar Overlay */}
      <div
        className={`absolute top-0 left-0 right-0 z-20 p-4 md:p-6 bg-gradient-to-b from-black/90 via-black/40 to-transparent flex items-center justify-between transition-opacity duration-300 ${
          controlsVisible ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
      >
        <div className="flex items-center gap-3 max-w-xl truncate">
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors"
            aria-label="Close player"
          >
            <X className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              {/* Stream Status Badge */}
              <span
                className={`flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-bold tracking-wider uppercase ${
                  streamStatus === 'live'
                    ? 'bg-[#E5093A] text-white'
                    : streamStatus === 'reconnecting'
                    ? 'bg-amber-500/30 text-amber-300 border border-amber-500/40 animate-pulse'
                    : 'bg-rose-500/30 text-rose-300 border border-rose-500/40'
                }`}
              >
                <span
                  className={`w-1.5 h-1.5 rounded-full ${
                    streamStatus === 'live'
                      ? 'bg-white animate-pulse'
                      : streamStatus === 'reconnecting'
                      ? 'bg-amber-400'
                      : 'bg-rose-400'
                  }`}
                />
                <span>
                  {streamStatus === 'live'
                    ? isLive ? 'LIVE' : 'PLAYING'
                    : streamStatus === 'reconnecting'
                    ? 'RECONNECTING'
                    : 'OFFLINE'}
                </span>
              </span>

              {!isLive && (
                <LegalBadge
                  status={movie ? movie.rightsStatus : 'PUBLIC_DOMAIN'}
                  licenseText={movie?.license}
                />
              )}

              <span className="text-xs text-slate-400 font-mono hidden sm:inline">
                Adaptive HLS
              </span>
            </div>

            <h2 className="text-base sm:text-lg font-bold text-white tracking-tight truncate mt-0.5">
              {mediaTitle}
            </h2>

            {/* EPG Program Info Overlay snippet */}
            {isLive && channel && (
              <p className="text-[11px] text-slate-300 truncate mt-0.5 flex items-center gap-2">
                <span className="text-cyan-400 font-medium">
                  {channel.epgProgram?.current || 'Live Broadcast'}
                </span>
                {channel.epgProgram?.next && (
                  <span className="text-slate-500 text-[10px] hidden sm:inline">
                    · Next: {channel.epgProgram.next}
                  </span>
                )}
              </p>
            )}
          </div>
        </div>

        {/* Top Right: Channel Switcher Drawer Toggle & Next/Prev */}
        <div className="flex items-center gap-2">
          {isLive && (
            <>
              {onPrevChannel && (
                <button
                  onClick={onPrevChannel}
                  className="hidden sm:inline-block px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs text-slate-200 transition-colors"
                >
                  Prev
                </button>
              )}
              {onNextChannel && (
                <button
                  onClick={onNextChannel}
                  className="hidden sm:inline-block px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs text-slate-200 transition-colors"
                >
                  Next
                </button>
              )}

              {/* Channel Switcher Drawer Trigger */}
              {channels.length > 0 && onSelectChannel && (
                <button
                  onClick={() => setShowDrawer(!showDrawer)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                    showDrawer
                      ? 'bg-[#E5093A] text-white'
                      : 'bg-white/10 hover:bg-white/20 text-slate-200'
                  }`}
                  title="Browse Channel Guide"
                >
                  <List className="w-3.5 h-3.5" />
                  <span>Channels ({channels.length})</span>
                </button>
              )}
            </>
          )}
        </div>
      </div>

      {/* Channel Switcher Drawer (Slide-in right panel) */}
      {showDrawer && isLive && onSelectChannel && (
        <div className="absolute top-0 right-0 bottom-0 w-80 sm:w-96 bg-[#080B12]/95 backdrop-blur-2xl border-l border-white/10 z-30 flex flex-col p-4 shadow-2xl animate-in slide-in-from-right duration-200">
          <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-3">
            <div className="flex items-center gap-2">
              <Tv className="w-4 h-4 text-[#E5093A]" />
              <h3 className="text-sm font-bold text-white font-display">Live Channels Drawer</h3>
            </div>
            <button
              onClick={() => setShowDrawer(false)}
              className="p-1 rounded-lg text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="relative mb-3">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={drawerSearch}
              onChange={(e) => setDrawerSearch(e.target.value)}
              placeholder="Filter channels..."
              className="w-full bg-[#111722] text-xs text-white pl-8 pr-3 py-2 rounded-xl border border-white/10 focus:outline-none focus:border-[#E5093A]"
            />
          </div>

          <div className="flex-1 overflow-y-auto space-y-1.5 pr-1">
            {drawerFilteredChannels.map((c) => {
              const isCurrent = channel?.id === c.id;
              return (
                <button
                  key={c.id}
                  onClick={() => {
                    onSelectChannel(c);
                  }}
                  className={`w-full flex items-center justify-between p-2.5 rounded-xl text-left transition-all ${
                    isCurrent
                      ? 'bg-[#E5093A]/20 border border-[#E5093A]/40 text-white'
                      : 'hover:bg-white/5 text-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-2.5 truncate mr-2">
                    <img
                      src={c.logo}
                      alt=""
                      className="w-6 h-6 object-contain rounded shrink-0 bg-black/40 p-0.5"
                      onError={(e) => ((e.target as HTMLElement).style.display = 'none')}
                    />
                    <div className="truncate">
                      <p className="text-xs font-semibold truncate leading-tight">{c.channelName}</p>
                      <p className="text-[10px] text-slate-500 truncate mt-0.5">
                        {c.epgProgram?.current || c.category}
                      </p>
                    </div>
                  </div>
                  {isCurrent ? (
                    <span className="w-2 h-2 rounded-full bg-[#E5093A] animate-pulse shrink-0" />
                  ) : (
                    <ChevronRight className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Bottom Transport Controls Overlay */}
      <div
        className={`absolute bottom-0 left-0 right-0 z-20 p-4 md:p-6 bg-gradient-to-t from-black/95 via-black/60 to-transparent transition-opacity duration-300 ${
          controlsVisible ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
      >
        {/* Seek Progress Bar (Non-Live Movies) */}
        {!isLive && duration > 0 && (
          <div className="mb-4 flex items-center gap-3">
            <span className="text-[11px] font-mono text-slate-300 tabular-nums">
              {formatTime(currentTime)}
            </span>
            <div className="relative flex-1 h-1.5 group/progress cursor-pointer">
              <input
                type="range"
                min={0}
                max={duration}
                value={currentTime}
                onChange={(e) => handleSeek(Number(e.target.value))}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
              />
              <div className="w-full h-full rounded-full bg-white/20 overflow-hidden">
                <div
                  className="h-full bg-[#E5093A] transition-all"
                  style={{ width: `${(currentTime / duration) * 100}%` }}
                />
              </div>
            </div>
            <span className="text-[11px] font-mono text-slate-400 tabular-nums">
              {formatTime(duration)}
            </span>
          </div>
        )}

        {/* Main Controls Row */}
        <div className="flex items-center justify-between">
          {/* Left Controls: Play/Pause, Replay 10s, Forward 10s, Volume */}
          <div className="flex items-center gap-2 sm:gap-4">
            <button
              onClick={togglePlay}
              className="p-2.5 rounded-xl bg-white/10 hover:bg-[#E5093A] text-white transition-colors"
              aria-label={isPlaying ? 'Pause' : 'Play'}
            >
              {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 fill-white" />}
            </button>

            {!isLive && (
              <>
                <button
                  onClick={() => handleSeek(Math.max(0, currentTime - 10))}
                  className="p-2 text-slate-300 hover:text-white transition-colors"
                  title="Rewind 10 seconds"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleSeek(Math.min(duration, currentTime + 10))}
                  className="p-2 text-slate-300 hover:text-white transition-colors"
                  title="Forward 10 seconds"
                >
                  <RotateCw className="w-4 h-4" />
                </button>
              </>
            )}

            {/* Volume Slider */}
            <div className="flex items-center gap-2 group/volume ml-2">
              <button
                onClick={toggleMute}
                className="text-slate-300 hover:text-white transition-colors"
                aria-label={isMuted ? 'Unmute' : 'Mute'}
              >
                {isMuted || volume === 0 ? (
                  <VolumeX className="w-5 h-5 text-rose-400" />
                ) : (
                  <Volume2 className="w-5 h-5" />
                )}
              </button>
              <input
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={isMuted ? 0 : volume}
                onChange={(e) => handleVolumeChange(Number(e.target.value))}
                className="w-16 sm:w-20 h-1 bg-white/20 accent-[#E5093A] cursor-pointer"
              />
            </div>
          </div>

          {/* Right Controls: Subtitles, Audio Tracks, Quality Selector, Fullscreen */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Audio Track Selector */}
            {audioTracks.length > 0 && (
              <div className="relative">
                <button
                  onClick={() => {
                    setShowAudioMenu(!showAudioMenu);
                    setShowQualityMenu(false);
                  }}
                  className="p-2 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
                  title="Audio Track Selector"
                >
                  <Music className="w-4 h-4" />
                </button>

                {showAudioMenu && (
                  <div className="absolute bottom-10 right-0 w-44 rounded-xl bg-[#111722] border border-white/10 shadow-2xl p-2 z-30">
                    <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider px-2 py-1">
                      Audio Tracks
                    </p>
                    {audioTracks.map((t) => (
                      <button
                        key={t.id}
                        onClick={() => handleAudioTrackSelect(t.id)}
                        className={`w-full text-left px-2 py-1.5 rounded text-xs transition-colors flex items-center justify-between ${
                          currentAudioTrack === t.id
                            ? 'bg-[#E5093A] text-white font-semibold'
                            : 'text-slate-300 hover:bg-white/5 hover:text-white'
                        }`}
                      >
                        <span className="truncate">{t.name}</span>
                        {currentAudioTrack === t.id && <Check className="w-3.5 h-3.5" />}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Quality Settings Dropdown */}
            {qualities.length > 0 && (
              <div className="relative">
                <button
                  onClick={() => {
                    setShowQualityMenu(!showQualityMenu);
                    setShowAudioMenu(false);
                  }}
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-medium text-slate-200 transition-colors"
                  title="Stream Quality"
                >
                  <Sliders className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">
                    {currentQuality === -1 ? 'Auto' : qualities.find((q) => q.id === currentQuality)?.name}
                  </span>
                </button>

                {showQualityMenu && (
                  <div className="absolute bottom-10 right-0 w-36 rounded-xl bg-[#111722] border border-white/10 shadow-2xl p-2 z-30">
                    <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider px-2 py-1">
                      Resolution
                    </p>
                    {qualities.map((q) => (
                      <button
                        key={q.id}
                        onClick={() => handleQualitySelect(q.id)}
                        className={`w-full text-left px-2 py-1.5 rounded text-xs transition-colors flex items-center justify-between ${
                          currentQuality === q.id
                            ? 'bg-[#E5093A] text-white font-semibold'
                            : 'text-slate-300 hover:bg-white/5 hover:text-white'
                        }`}
                      >
                        <span>{q.name}</span>
                        {currentQuality === q.id && <Check className="w-3.5 h-3.5" />}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Subtitles Toggle */}
            <button
              onClick={() => setSubtitlesEnabled(!subtitlesEnabled)}
              className={`p-2 rounded-lg transition-colors ${
                subtitlesEnabled ? 'text-[#E5093A]' : 'text-slate-400 hover:text-white'
              }`}
              title="Toggle Subtitles"
            >
              <Subtitles className="w-4 h-4" />
            </button>

            {/* Fullscreen Toggle */}
            <button
              onClick={toggleFullscreen}
              className="p-2 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
              title={isFullscreen ? 'Exit Fullscreen (F)' : 'Enter Fullscreen (F)'}
            >
              {isFullscreen ? <Minimize className="w-5 h-5" /> : <Maximize className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Legal Attribution Notice Footer */}
        <div className="mt-3 pt-2 border-t border-white/10 flex flex-wrap items-center justify-between text-[11px] text-slate-400">
          <p className="truncate max-w-md">
            Source: <span className="text-slate-300">{channel?.sourceName || movie?.source || 'Authorized Stream'}</span>
            {movie?.attribution ? ` · ${movie.attribution}` : ''}
          </p>
          <span className="text-[10px] text-emerald-400 font-mono">
            VERIFIED LEGAL STREAM
          </span>
        </div>
      </div>
    </div>
  );
};
