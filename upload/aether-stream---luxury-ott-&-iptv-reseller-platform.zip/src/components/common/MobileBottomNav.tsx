import React from 'react';
import { Home, Tv, Film, Bookmark, User } from 'lucide-react';

interface MobileBottomNavProps {
  currentTab: string;
  onNavigate: (tab: string) => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({ currentTab, onNavigate }) => {
  const tabs = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'live-tv', label: 'Live TV', icon: Tv },
    { id: 'movies', label: 'Cinema', icon: Film },
    { id: 'my-list', label: 'My List', icon: Bookmark },
    { id: 'dashboard', label: 'Account', icon: User },
  ];

  return (
    <nav
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#080B12]/95 backdrop-blur-xl border-t border-white/10 px-2 pb-safe"
      style={{ height: '60px' }}
      aria-label="Mobile Navigation"
    >
      <div className="grid grid-cols-5 h-full items-center">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = currentTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onNavigate(tab.id)}
              className="flex flex-col items-center justify-center min-h-[48px] w-full transition-colors relative"
              aria-label={tab.label}
            >
              <div className="relative">
                <Icon
                  className={`w-5 h-5 transition-transform ${
                    isActive ? 'text-[#E5093A] scale-110' : 'text-[#818B9A]'
                  }`}
                />
                {isActive && (
                  <span className="absolute -top-1 -right-1 w-1.5 h-1.5 rounded-full bg-[#E5093A] shadow-[0_0_6px_#E5093A]" />
                )}
              </div>
              <span
                className={`text-[10px] font-medium tracking-tight mt-1 truncate ${
                  isActive ? 'text-white font-semibold' : 'text-[#818B9A]'
                }`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
