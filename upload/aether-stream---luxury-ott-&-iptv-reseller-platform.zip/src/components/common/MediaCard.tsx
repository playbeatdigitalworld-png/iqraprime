import React, { useState } from 'react';
import { Play, Plus, Check, Info } from 'lucide-react';
import type { Movie, WatchProgress } from '../../types/index.js';
import { useWatchlist } from '../../context/WatchlistContext.js';
import { LegalBadge } from './LegalBadge.js';

interface MediaCardProps {
  movie: Movie;
  progress?: WatchProgress;
  onPlay: (movie: Movie, mode?: 'full' | 'trailer') => void;
  onOpenDetails: (movie: Movie) => void;
  aspectRatio?: 'poster' | 'landscape';
}

export const MediaCard: React.FC<MediaCardProps> = ({
  movie,
  progress,
  onPlay,
  onOpenDetails,
  aspectRatio = 'landscape',
}) => {
  const { isInWatchlist, toggleWatchlist } = useWatchlist();
  const inList = isInWatchlist(movie.id);
  const [imgError, setImgError] = useState(false);

  const canPlayFull = Boolean(movie.videoUrl) && movie.rightsStatus !== 'TRAILER_ONLY';
  const progressPercent =
    progress && progress.durationSeconds > 0
      ? Math.min(100, Math.round((progress.positionSeconds / progress.durationSeconds) * 100))
      : 0;

  return (
    <div
      className={`group relative flex flex-col rounded-xl overflow-hidden bg-[#111722] border border-white/5 hover:border-white/20 transition-all duration-300 hover:shadow-2xl hover:shadow-black/60 shrink-0 ${
        aspectRatio === 'poster' ? 'w-[160px] sm:w-[200px]' : 'w-[260px] sm:w-[320px]'
      }`}
    >
      {/* Media Image Frame */}
      <div
        className={`relative w-full overflow-hidden bg-[#080B12] ${
          aspectRatio === 'poster' ? 'aspect-[2/3]' : 'aspect-video'
        }`}
      >
        {!imgError ? (
          <img
            src={aspectRatio === 'poster' ? movie.poster : movie.backdrop || movie.poster}
            alt={movie.title}
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center p-4 bg-gradient-to-br from-[#151D29] to-[#080B12] text-center">
            <span className="text-xs font-semibold text-white font-display mb-1">{movie.title}</span>
            <span className="text-[10px] text-slate-400">{movie.year}</span>
          </div>
        )}

        {/* Ambient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#111722] via-transparent to-transparent opacity-80" />

        {/* Progress Bar (Continue Watching) */}
        {progressPercent > 0 && (
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-black/60 z-20">
            <div
              className="h-full bg-[#E5093A]"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        )}

        {/* Hover Quick Action Tray */}
        <div className="absolute inset-0 z-20 bg-black/50 backdrop-blur-[2px] opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center gap-2">
          <button
            onClick={() => onPlay(movie, canPlayFull ? 'full' : 'trailer')}
            className="w-10 h-10 rounded-full bg-[#E5093A] hover:bg-[#B90732] text-white flex items-center justify-center shadow-lg transition-transform hover:scale-110 active:scale-95"
            title={canPlayFull ? 'Watch Full Feature' : 'Watch Official Trailer'}
          >
            <Play className="w-4 h-4 fill-white ml-0.5" />
          </button>
          <button
            onClick={() => toggleWatchlist(movie.id, movie.title)}
            className={`w-9 h-9 rounded-full border flex items-center justify-center transition-transform hover:scale-110 ${
              inList
                ? 'bg-emerald-500/30 border-emerald-400 text-emerald-300'
                : 'bg-black/60 border-white/20 text-white hover:bg-black/80'
            }`}
            title={inList ? 'Remove from My List' : 'Add to My List'}
          >
            {inList ? <Check className="w-4 h-4 text-emerald-400" /> : <Plus className="w-4 h-4" />}
          </button>
          <button
            onClick={() => onOpenDetails(movie)}
            className="w-9 h-9 rounded-full bg-black/60 border border-white/20 text-white flex items-center justify-center hover:bg-black/80 transition-transform hover:scale-110"
            title="Inspect Details & Rights"
          >
            <Info className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Card Info Details */}
      <div className="p-3 flex flex-col flex-1 justify-between">
        <div>
          <div className="flex items-center justify-between gap-1 mb-1">
            <LegalBadge status={movie.rightsStatus} />
            <span className="text-[10px] text-amber-400 font-semibold">{movie.rating}</span>
          </div>
          <h3 className="text-xs sm:text-sm font-semibold text-white tracking-tight line-clamp-1 group-hover:text-[#E5093A] transition-colors">
            {movie.title}
          </h3>
        </div>

        {/* Unboxed Metadata (Zero-Pill discipline) */}
        <div className="mt-2 flex items-center gap-1.5 text-[11px] text-[#818B9A] truncate">
          <span>{movie.year}</span>
          <span aria-hidden="true">·</span>
          <span>{movie.duration}</span>
          <span aria-hidden="true">·</span>
          <span className="truncate">{movie.genre[0]}</span>
        </div>
      </div>
    </div>
  );
};
