import React, { useState, useEffect } from 'react';
import { Search, Shield, LogOut, Film, User as UserIcon } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.js';
import { PWAInstallButton } from './PWAInstallButton.js';

interface NavbarProps {
  currentTab: string;
  onNavigate: (tab: string) => void;
  onOpenSearch: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentTab, onNavigate, onOpenSearch }) => {
  const { user, isAdmin, logout, quickSwitchPersona } = useAuth();
  const [isScrolled, setIsScrolled] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { id: 'home', label: 'Home' },
    { id: 'live-tv', label: 'Live TV' },
    { id: 'movies', label: 'Cinema' },
    { id: 'my-list', label: 'My List' },
    { id: 'dashboard', label: 'Devices' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#080B12]/95 backdrop-blur-xl border-b border-white/10 py-3 shadow-2xl'
          : 'bg-gradient-to-b from-[#05070B]/90 via-[#05070B]/50 to-transparent py-4'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        {/* Zone 1: Brand Wordmark (Single text element in Cinzel display face) */}
        <button
          onClick={() => onNavigate('home')}
          className="group flex items-center gap-2.5 text-left focus:outline-none"
        >
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#E5093A] to-[#80041B] flex items-center justify-center shadow-lg crimson-glow-sm">
            <Film className="w-4 h-4 text-white" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-lg md:text-xl font-bold tracking-widest text-white font-display whitespace-nowrap">
              AETHER <span className="text-[#E5093A]">STREAM</span>
            </span>
            <span className="hidden sm:inline-block text-[9px] font-mono tracking-widest uppercase text-cyan-400 font-semibold">
              CLOSED BETA
            </span>
          </div>
        </button>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium">
          {navLinks.map((link) => {
            const isActive = currentTab === link.id;
            return (
              <button
                key={link.id}
                onClick={() => onNavigate(link.id)}
                className={`relative py-1 transition-colors whitespace-nowrap ${
                  isActive ? 'text-white font-semibold' : 'text-[#B8C1CE] hover:text-white'
                }`}
              >
                {link.label}
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#E5093A] rounded-full shadow-[0_0_8px_#E5093A]" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Actions (Search, PWA Install, Profile) */}
        <div className="flex items-center gap-3">
          {/* Instant Search trigger */}
          <button
            onClick={onOpenSearch}
            className="p-2 rounded-lg text-[#B8C1CE] hover:text-white hover:bg-white/5 transition-colors focus:outline-none"
            aria-label="Search content"
            title="Search movies & live channels"
          >
            <Search className="w-4 h-4" />
          </button>

          {/* In-app PWA install button */}
          <div className="hidden sm:block">
            <PWAInstallButton compact />
          </div>

          {/* User Profile / Admin Menu */}
          <div className="relative">
            <button
              onClick={() => setProfileOpen(!profileOpen)}
              className="flex items-center gap-2 p-1.5 rounded-lg border border-white/10 hover:border-white/20 bg-white/5 text-sm transition-all focus:outline-none"
              aria-expanded={profileOpen}
              aria-label="User profile menu"
            >
              {user?.avatarUrl ? (
                <img
                  src={user.avatarUrl}
                  alt={user.name}
                  referrerPolicy="no-referrer"
                  className="w-6 h-6 rounded-md object-cover"
                />
              ) : (
                <div className="w-6 h-6 rounded-md bg-[#192231] flex items-center justify-center text-xs font-bold text-white">
                  {user?.name ? user.name[0] : 'U'}
                </div>
              )}
              <span className="hidden lg:inline text-xs font-medium text-slate-200 max-w-[120px] truncate">
                {user?.name || 'Private Member'}
              </span>
            </button>

            {/* Profile Menu Dropdown */}
            {profileOpen && (
              <>
                <div
                  className="fixed inset-0 z-30"
                  onClick={() => setProfileOpen(false)}
                />
                <div className="absolute right-0 mt-2 w-72 rounded-xl bg-[#111722] border border-white/10 shadow-2xl z-40 py-2 animate-in fade-in zoom-in-95 duration-150">
                  <div className="px-4 py-2.5 border-b border-white/10">
                    <p className="text-xs font-semibold text-white truncate">{user?.name || 'Private Guest'}</p>
                    <p className="text-[11px] text-slate-400 truncate">{user?.email || 'Member account'}</p>
                    <div className="mt-1 flex items-center justify-between text-[10px]">
                      <span className="tracking-wider uppercase font-semibold text-[#E5093A]">
                        {isAdmin ? 'Director / Admin' : 'Approved Member'}
                      </span>
                      <span className="text-slate-400 font-mono">Pilot Access</span>
                    </div>
                  </div>

                  <div className="py-1 text-xs">
                    <button
                      onClick={() => {
                        setProfileOpen(false);
                        onNavigate('dashboard');
                      }}
                      className="w-full text-left px-4 py-2 text-slate-200 hover:bg-white/5 hover:text-white flex items-center gap-2"
                    >
                      <UserIcon className="w-3.5 h-3.5 text-slate-400" />
                      <span>Member Devices & Access</span>
                    </button>
                    {isAdmin && (
                      <button
                        onClick={() => {
                          setProfileOpen(false);
                          onNavigate('admin');
                        }}
                        className="w-full text-left px-4 py-2 text-slate-200 hover:bg-white/5 hover:text-white flex items-center gap-2"
                      >
                        <Shield className="w-3.5 h-3.5 text-[#E5093A]" />
                        <span>Director Console (Members & Star IPTV)</span>
                      </button>
                    )}
                  </div>

                  {/* Fast Approved Member Persona Switcher */}
                  <div className="px-4 py-2.5 border-t border-white/10 bg-[#080B12]/50">
                    <p className="text-[10px] uppercase font-semibold text-slate-400 tracking-wider mb-1.5">
                      Pilot Member Persona
                    </p>
                    <div className="grid grid-cols-3 gap-1">
                      <button
                        onClick={() => {
                          quickSwitchPersona('customer');
                          setProfileOpen(false);
                        }}
                        className="px-1.5 py-1 text-[10px] font-medium rounded bg-white/5 hover:bg-white/10 text-slate-200 text-center truncate"
                        title="Julian Vance"
                      >
                        Julian (M1)
                      </button>
                      <button
                        onClick={() => {
                          quickSwitchPersona('elena');
                          setProfileOpen(false);
                        }}
                        className="px-1.5 py-1 text-[10px] font-medium rounded bg-white/5 hover:bg-white/10 text-slate-200 text-center truncate"
                        title="Elena Rostova"
                      >
                        Elena (M2)
                      </button>
                      <button
                        onClick={() => {
                          quickSwitchPersona('admin');
                          setProfileOpen(false);
                        }}
                        className="px-1.5 py-1 text-[10px] font-medium rounded bg-[#E5093A]/20 hover:bg-[#E5093A]/30 text-[#E5093A] text-center truncate"
                        title="System Director"
                      >
                        Director
                      </button>
                    </div>
                  </div>

                  {user && (
                    <div className="pt-1 border-t border-white/10">
                      <button
                        onClick={() => {
                          logout();
                          setProfileOpen(false);
                        }}
                        className="w-full text-left px-4 py-2 text-xs text-rose-400 hover:bg-rose-500/10 flex items-center gap-2"
                      >
                        <LogOut className="w-3.5 h-3.5" />
                        <span>Sign Out</span>
                      </button>
                    </div>
                  )}
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
