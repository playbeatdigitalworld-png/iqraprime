import React from 'react';
import { Play, Film, Plus, Check } from 'lucide-react';
import type { Movie } from '../../types/index.js';
import { useWatchlist } from '../../context/WatchlistContext.js';
import { LegalBadge } from './LegalBadge.js';

interface HeroBannerProps {
  movie: Movie;
  onPlay: (movie: Movie, mode?: 'full' | 'trailer') => void;
  onOpenDetails: (movie: Movie) => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({ movie, onPlay, onOpenDetails }) => {
  const { isInWatchlist, toggleWatchlist } = useWatchlist();
  const inList = isInWatchlist(movie.id);

  const canPlayFull = Boolean(movie.videoUrl) && movie.rightsStatus !== 'TRAILER_ONLY';

  return (
    <section className="relative w-full h-[75vh] min-h-[520px] max-h-[820px] overflow-hidden flex items-end">
      {/* Cinematic Backdrop Image with Fallback */}
      <div className="absolute inset-0 z-0">
        <img
          src={movie.backdrop || movie.poster}
          alt={movie.title}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center scale-105 transition-transform duration-1000 ease-out"
        />
        {/* Multistage cinematic gradient overlays */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#05070B] via-[#05070B]/60 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#05070B] via-[#05070B]/80 to-transparent w-full md:w-3/4" />
        <div className="absolute inset-0 bg-radial-gradient from-transparent via-[#05070B]/30 to-[#05070B]/90" />
      </div>

      {/* Hero Content Container */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16 md:pb-24 w-full">
        <div className="max-w-2xl">
          {/* Unboxed Metadata & Category Kicker */}
          <div className="flex flex-wrap items-center gap-2 text-xs text-[#B8C1CE] mb-3">
            <LegalBadge status={movie.rightsStatus} licenseText={movie.license} />
            <span aria-hidden="true" className="text-white/30">·</span>
            <span>{movie.year}</span>
            <span aria-hidden="true" className="text-white/30">·</span>
            <span>{movie.duration}</span>
            <span aria-hidden="true" className="text-white/30">·</span>
            <span className="text-amber-400 font-semibold">{movie.rating}</span>
            <span aria-hidden="true" className="text-white/30">·</span>
            <span>{movie.genre.slice(0, 2).join(' / ')}</span>
          </div>

          {/* Cinematic Title */}
          <h1 className="text-3xl sm:text-4xl md:text-6xl font-extrabold text-white font-display tracking-tight leading-none mb-4 drop-shadow-lg">
            {movie.title}
          </h1>

          {/* Description */}
          <p className="text-sm md:text-base text-slate-300 line-clamp-3 mb-8 leading-relaxed max-w-xl font-normal drop-shadow">
            {movie.description}
          </p>

          {/* Action Button Row */}
          <div className="flex flex-wrap items-center gap-3">
            {canPlayFull ? (
              <button
                onClick={() => onPlay(movie, 'full')}
                className="flex items-center gap-2.5 px-6 py-3.5 rounded-xl bg-[#E5093A] hover:bg-[#B90732] text-white font-semibold text-sm shadow-xl crimson-glow transition-all duration-200 active:scale-95 whitespace-nowrap"
              >
                <Play className="w-4 h-4 fill-white" />
                <span>Watch Feature</span>
              </button>
            ) : (
              <button
                onClick={() => onPlay(movie, 'trailer')}
                className="flex items-center gap-2.5 px-6 py-3.5 rounded-xl bg-[#E5093A] hover:bg-[#B90732] text-white font-semibold text-sm shadow-xl crimson-glow transition-all duration-200 active:scale-95 whitespace-nowrap"
              >
                <Play className="w-4 h-4 fill-white" />
                <span>Watch Trailer</span>
              </button>
            )}

            {canPlayFull && movie.trailerUrl && (
              <button
                onClick={() => onPlay(movie, 'trailer')}
                className="flex items-center gap-2 px-5 py-3.5 rounded-xl bg-white/10 hover:bg-white/15 border border-white/10 text-white font-medium text-sm backdrop-blur-md transition-colors whitespace-nowrap"
              >
                <Film className="w-4 h-4 text-[#B8C1CE]" />
                <span>Trailer</span>
              </button>
            )}

            <button
              onClick={() => toggleWatchlist(movie.id, movie.title)}
              className={`flex items-center gap-2 px-4 py-3.5 rounded-xl border text-sm font-medium transition-colors whitespace-nowrap ${
                inList
                  ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
                  : 'bg-black/40 hover:bg-white/5 border-white/15 text-slate-200'
              }`}
              title={inList ? 'Remove from My List' : 'Add to My List'}
            >
              {inList ? <Check className="w-4 h-4 text-emerald-400" /> : <Plus className="w-4 h-4" />}
              <span className="hidden sm:inline">{inList ? 'In My List' : 'Add to List'}</span>
            </button>

            <button
              onClick={() => onOpenDetails(movie)}
              className="px-4 py-3.5 rounded-xl text-xs font-semibold text-slate-300 hover:text-white transition-colors"
            >
              Details & License
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
