/**
 * Aether Stream — Luxury Cinematic OTT & Authorized Reseller Platform
 */

import React, { useState, useEffect } from 'react';
import type { Channel, Movie } from './types/index.js';
import { api } from './services/api.js';
import { ToastProvider } from './context/ToastContext.js';
import { AuthProvider, useAuth } from './context/AuthContext.js';
import { WatchlistProvider, useWatchlist } from './context/WatchlistContext.js';

import { Navbar } from './components/common/Navbar.js';
import { MobileBottomNav } from './components/common/MobileBottomNav.js';
import { Footer } from './components/common/Footer.js';
import { OfflineIndicator } from './components/common/OfflineIndicator.js';
import { SearchModal } from './components/common/SearchModal.js';
import { MediaPlayerModal } from './components/player/MediaPlayerModal.js';

import { HomePage } from './pages/HomePage.js';
import { LiveTVPage } from './pages/LiveTVPage.js';
import { MoviesPage } from './pages/MoviesPage.js';
import { MyListPage } from './pages/MyListPage.js';
import { PricingPage } from './pages/PricingPage.js';
import { DashboardPage } from './pages/DashboardPage.js';
import { AdminPage } from './pages/AdminPage.js';
import { LegalPage } from './pages/LegalPage.js';
import { MovieDetailPage } from './pages/MovieDetailPage.js';


const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { user, status, isLoading } = useAuth();
  if (isLoading) return <div>Loading...</div>;
  if (!user) return <div>Please log in</div>;
  if (status !== 'active') return <div>Account pending or disabled.</div>;
  return <>{children}</>;
};

const AdminRoute = ({ children }: { children: React.ReactNode }) => {
  const { user, isAdmin, isLoading } = useAuth();
  if (isLoading) return <div>Loading...</div>;
  if (!user || !isAdmin) return <div>Access denied</div>;
  return <>{children}</>;
};

function MainApp() {

  const { playerState, openPlayer, closePlayer, continueWatching } = useWatchlist();

  const [currentTab, setCurrentTab] = useState<string>('home');
  const [movies, setMovies] = useState<Movie[]>([]);
  const [channels, setChannels] = useState<Channel[]>([]);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [detailMovie, setDetailMovie] = useState<Movie | null>(null);

  // Load verified content
  useEffect(() => {
    async function loadContent() {
      try {
        const [movs, chans] = await Promise.all([
          api.getMovies(),
          api.getChannels(),
        ]);
        setMovies(movs);
        setChannels(chans);
      } catch (e) {
        console.error('Failed to load initial catalog:', e);
      }
    }
    loadContent();
  }, []);

  const handlePlayMovie = (movie: Movie, mode: 'full' | 'trailer' = 'full') => {
    openPlayer({ movie, mode });
  };

  const handlePlayChannel = (channel: Channel) => {
    openPlayer({ channel, mode: 'full' });
  };

  const handleNextChannel = () => {
    if (!playerState.channel) return;
    const currentIdx = channels.findIndex((c) => c.id === playerState.channel!.id);
    const nextIdx = (currentIdx + 1) % channels.length;
    openPlayer({ channel: channels[nextIdx], mode: 'full' });
  };

  const handlePrevChannel = () => {
    if (!playerState.channel) return;
    const currentIdx = channels.findIndex((c) => c.id === playerState.channel!.id);
    const prevIdx = (currentIdx - 1 + channels.length) % channels.length;
    openPlayer({ channel: channels[prevIdx], mode: 'full' });
  };

  return (
    <div className="min-h-screen bg-[#05070B] text-[#F5F7FA] flex flex-col font-sans-custom">
      {/* Offline Status Badge */}
      <OfflineIndicator />

      {/* Floating Glass Navigation Header */}
      <Navbar
        currentTab={currentTab}
        onNavigate={setCurrentTab}
        onOpenSearch={() => setIsSearchOpen(true)}
      />

      {/* Main Dynamic View Area */}
      <main className="flex-1">
        {currentTab === 'home' && (
          <HomePage
            movies={movies}
            channels={channels}
            continueWatching={continueWatching}
            onPlayMovie={handlePlayMovie}
            onPlayChannel={handlePlayChannel}
            onOpenDetails={setDetailMovie}
            onNavigate={setCurrentTab}
          />
        )}

        {currentTab === 'live-tv' && (
          <ProtectedRoute>
            <LiveTVPage
              channels={channels}
              onPlayChannel={handlePlayChannel}
            />
          </ProtectedRoute>
        )}

        {currentTab === 'movies' && (
          <ProtectedRoute>
            <MoviesPage
              movies={movies}
              onPlayMovie={handlePlayMovie}
              onOpenDetails={setDetailMovie}
            />
          </ProtectedRoute>
        )}

        {currentTab === 'free-cinema' && (
          <MoviesPage
            movies={movies}
            onPlayMovie={handlePlayMovie}
            onOpenDetails={setDetailMovie}
            publicDomainOnly={true}
          />
        )}

        {currentTab === 'pricing' && (
          <PricingPage onNavigate={setCurrentTab} />
        )}

        {currentTab === 'my-list' && (
          <ProtectedRoute>
            <MyListPage
              movies={movies}
              channels={channels}
              onPlayMovie={handlePlayMovie}
              onPlayChannel={handlePlayChannel}
              onOpenDetails={setDetailMovie}
              onNavigate={setCurrentTab}
            />
          </ProtectedRoute>
        )}

        {currentTab === 'dashboard' && (
          <ProtectedRoute>
            <DashboardPage onNavigate={setCurrentTab} />
          </ProtectedRoute>
        )}

        {currentTab === 'admin' && (
          <AdminRoute>
            <AdminPage onNavigate={setCurrentTab} />
          </AdminRoute>
        )}

        {/* Legal Sub-sections */}
        {(currentTab === 'copyright' ||
          currentTab === 'takedown' ||
          currentTab === 'terms' ||
          currentTab === 'privacy' ||
          currentTab === 'refund' ||
          currentTab === 'refund-policy' ||
          currentTab === 'disclaimer' ||
          currentTab === 'contact') && (
          <LegalPage
            section={
              currentTab === 'refund-policy'
                ? 'refund'
                : (currentTab as any)
            }
            onNavigate={setCurrentTab}
          />
        )}
      </main>

      {/* Luxury Cinematic Footer */}
      <Footer onNavigate={setCurrentTab} />

      {/* Mobile-First Bottom Navigation Bar */}
      <MobileBottomNav
        currentTab={currentTab}
        onNavigate={setCurrentTab}
      />

      {/* Immersive Search Modal */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        movies={movies}
        channels={channels}
        onPlayMovie={handlePlayMovie}
        onPlayChannel={handlePlayChannel}
      />

      {/* Movie Details Modal */}
      {detailMovie && (
        <MovieDetailPage
          movie={detailMovie}
          allMovies={movies}
          onPlay={handlePlayMovie}
          onOpenDetails={setDetailMovie}
          onClose={() => setDetailMovie(null)}
        />
      )}

      {/* Master Streaming Video Player Modal */}
      {playerState.isOpen && (
        <MediaPlayerModal
          movie={playerState.movie}
          channel={playerState.channel}
          mode={playerState.mode}
          startPosition={playerState.startPosition}
          onClose={closePlayer}
          onNextChannel={handleNextChannel}
          onPrevChannel={handlePrevChannel}
          channels={channels}
          onSelectChannel={handlePlayChannel}
        />
      )}
    </div>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <AuthProvider>
        <WatchlistProvider>
          <MainApp />
        </WatchlistProvider>
      </AuthProvider>
    </ToastProvider>
  );
}
