import React, { useState } from 'react';
import {
  ShieldCheck,
  Users,
  Tv,
  Smartphone,
  Lock,
  ArrowRight,
  Info,
  CheckCircle2,
  FileText,
  KeyRound,
  LogIn,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.js';
import { useToast } from '../context/ToastContext.js';
import { api } from '../services/api.js';

interface PricingPageProps {
  onNavigate: (tab: string) => void;
}

export const PricingPage: React.FC<PricingPageProps> = ({ onNavigate }) => {
  const { user, subscription, isAdmin, login, quickSwitchPersona } = useAuth();
  const { showToast } = useToast();

  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  const handleMemberLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginEmail || !loginPassword) {
      showToast('Please enter both email and password', 'error');
      return;
    }

    setIsLoggingIn(true);
    try {
      await login(loginEmail, loginPassword);
      showToast('Welcome to Aether Stream Private Pilot', 'success');
      onNavigate('home');
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Login failed', 'error');
    } finally {
      setIsLoggingIn(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-20 min-h-screen">
      {/* Pilot Header */}
      <div className="text-center max-w-3xl mx-auto mb-12">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-semibold mb-4 font-mono">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
          <span>PRE-COMMERCIAL PILOT · 3–5 HOUSEHOLD MEMBERS</span>
        </div>

        <h1 className="text-3xl sm:text-5xl font-extrabold text-white font-display tracking-tight leading-tight">
          Private Access & Testing Portal
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-3 leading-relaxed">
          Aether Stream is operating in closed-beta mode for private testing of streaming infrastructure,
          adaptive bitrate playback, device concurrency, and authorized Star IPTV integration.
        </p>
      </div>

      {/* Mandatory Regulatory & SECP Corporate Notice Banner */}
      <div className="mb-12 p-6 rounded-2xl bg-[#111722] border border-amber-500/30 shadow-xl relative overflow-hidden">
        <div className="flex items-start gap-3.5">
          <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400 shrink-0">
            <FileText className="w-5 h-5" />
          </div>
          <div className="space-y-1">
            <h3 className="text-sm font-bold text-white font-display">
              SECP Corporate Registration & Pre-Launch Notice
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Aether Stream is currently in a <strong>private closed-beta pilot for authorized household members</strong>.
              Commercial service launch, public subscriptions, and payment processing are strictly withheld pending
              formal Securities and Exchange Commission of Pakistan (SECP) corporate registration and relevant regulatory approvals.
            </p>
            <p className="text-[11px] text-amber-300 font-medium pt-1">
              • Public registration and payment gateways are disabled in this environment.
            </p>
          </div>
        </div>
      </div>

      {/* Current Pilot Capacity & Feature Pillars */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        {/* Pillar 1: Controlled Membership */}
        <div className="p-6 rounded-2xl bg-[#111722] border border-white/10 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center">
            <Users className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-white font-display">
            3–5 Approved Members
          </h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Access is provisioned exclusively by the System Director. Household members test video feeds, device limits, and custom watchlists.
          </p>
          <div className="pt-2 text-[11px] font-mono text-emerald-400 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Currently Active: Julian Vance & Elena Rostova</span>
          </div>
        </div>

        {/* Pillar 2: Star IPTV Line Integration */}
        <div className="p-6 rounded-2xl bg-[#111722] border border-white/10 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-[#E5093A]/10 text-[#E5093A] flex items-center justify-center">
            <Tv className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-white font-display">
            Authorized Star IPTV Testing
          </h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Secure server-side adapter validates M3U playlists, parses electronic program guides (EPG), and routes streams through protected player endpoints.
          </p>
          <div className="pt-2 text-[11px] font-mono text-cyan-400 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Server Vault Enforced · Zero Client Exposure</span>
          </div>
        </div>

        {/* Pillar 3: Concurrency & Device Management */}
        <div className="p-6 rounded-2xl bg-[#111722] border border-white/10 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-purple-500/10 text-purple-400 flex items-center justify-center">
            <Smartphone className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-white font-display">
            2 Devices Per Member
          </h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Each household slot allows 2 active device sessions (Smart TV, mobile PWA, or studio desktop). Older sessions can be revoked on demand.
          </p>
          <div className="pt-2 text-[11px] font-mono text-purple-400 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Smart TV & PWA Offline Sync Ready</span>
          </div>
        </div>
      </div>

      {/* Member Session or Pilot Sign-In Section */}
      <div className="max-w-xl mx-auto rounded-2xl bg-[#111722] border border-white/10 p-6 sm:p-8 shadow-2xl">
        {user ? (
          <div className="space-y-4 text-center">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 mx-auto flex items-center justify-center">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white font-display">
                Authorized Pilot Member Active
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Signed in as <strong className="text-white">{user.name}</strong> ({user.email})
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-[#080B12] border border-white/5 text-xs text-slate-300 space-y-2 text-left">
              <div className="flex justify-between">
                <span className="text-slate-400">Access Status:</span>
                <span className="text-emerald-400 font-semibold font-mono">Approved Pilot Pass</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Role:</span>
                <span className="capitalize text-slate-200">{isAdmin ? 'Director (Admin)' : 'Household Member'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Device Allocation:</span>
                <span className="font-mono text-slate-200">{subscription?.maxDevices || 2} Connected Screens</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
              <button
                onClick={() => onNavigate('home')}
                className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-[#E5093A] hover:bg-[#B90732] text-white text-xs font-semibold shadow-md crimson-glow-sm transition-all"
              >
                Enter Streaming Theater
              </button>
              <button
                onClick={() => onNavigate('dashboard')}
                className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-semibold border border-white/10 transition-colors"
              >
                Manage My Devices
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-5">
            <div className="text-center">
              <div className="w-10 h-10 rounded-xl bg-[#E5093A]/10 text-[#E5093A] mx-auto flex items-center justify-center mb-3">
                <Lock className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-white font-display">
                Member Access Login
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Enter your credentials provided by the platform director.
              </p>
            </div>

            <form onSubmit={handleMemberLogin} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1 font-semibold">Email Address</label>
                <input
                  type="email"
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  placeholder="julian@aetherstream.tv"
                  className="w-full bg-[#080B12] border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#E5093A]"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1 font-semibold">Password</label>
                <input
                  type="password"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-[#080B12] border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#E5093A]"
                />
              </div>

              <button
                type="submit"
                disabled={isLoggingIn}
                className="w-full py-2.5 rounded-xl bg-[#E5093A] hover:bg-[#B90732] text-white font-semibold transition-all disabled:opacity-50"
              >
                {isLoggingIn ? 'Authenticating...' : 'Sign In with Member Pass'}
              </button>
            </form>

            <div className="pt-3 border-t border-white/5 text-center">
              <p className="text-[11px] text-slate-400 mb-2">Or instant switch for testing:</p>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => quickSwitchPersona('customer')}
                  className="py-1.5 px-2 rounded-lg bg-white/5 hover:bg-white/10 text-xs text-slate-300 font-medium border border-white/5"
                >
                  Julian (M1)
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    try {
                      await login('elena@aetherstream.tv', 'member123');
                    } catch {}
                  }}
                  className="py-1.5 px-2 rounded-lg bg-white/5 hover:bg-white/10 text-xs text-slate-300 font-medium border border-white/5"
                >
                  Elena (M2)
                </button>
                <button
                  type="button"
                  onClick={() => quickSwitchPersona('admin')}
                  className="py-1.5 px-2 rounded-lg bg-[#E5093A]/20 hover:bg-[#E5093A]/30 text-xs text-[#E5093A] font-semibold border border-[#E5093A]/30"
                >
                  Director (Admin)
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
