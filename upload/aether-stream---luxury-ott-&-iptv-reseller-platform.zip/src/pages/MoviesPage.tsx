import React, { useState, useMemo } from 'react';
import type { Movie } from '../types/index.js';
import { MediaCard } from '../components/common/MediaCard.js';
import { Film, Search, ShieldCheck } from 'lucide-react';

interface MoviesPageProps {
  movies: Movie[];
  onPlayMovie: (movie: Movie, mode?: 'full' | 'trailer') => void;
  onOpenDetails: (movie: Movie) => void;
  publicDomainOnly?: boolean;
}

export const MoviesPage: React.FC<MoviesPageProps> = ({
  movies,
  onPlayMovie,
  onOpenDetails,
  publicDomainOnly = false,
}) => {
  const [selectedGenre, setSelectedGenre] = useState<string>('All');
  const [selectedLicense, setSelectedLicense] = useState<string>(publicDomainOnly ? 'PUBLIC_DOMAIN' : 'All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const genres = ['All', 'Sci-Fi', 'Mystery', 'Comedy', 'Horror', 'Animation', 'Action'];

  const filteredMovies = useMemo(() => {
    return movies.filter((m) => {
      if (!m.enabled) return false;
      const matchesGenre = selectedGenre === 'All' || m.genre.includes(selectedGenre);
      const matchesLicense =
        selectedLicense === 'All'
          ? true
          : selectedLicense === 'PUBLIC_DOMAIN'
          ? m.rightsStatus === 'PUBLIC_DOMAIN'
          : m.rightsStatus === 'OPEN_LICENSE';
      const matchesSearch =
        !searchQuery ||
        m.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        m.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        m.genre.some((g) => g.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchesGenre && matchesLicense && matchesSearch;
    });
  }, [movies, selectedGenre, selectedLicense, searchQuery]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-16 min-h-screen">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-2 text-xs font-semibold text-[#E5093A] uppercase tracking-wider">
          <Film className="w-3.5 h-3.5" />
          <span>{publicDomainOnly ? 'Public Domain Archives' : 'Curated Cinema & Masterpieces'}</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white font-display tracking-tight">
          {publicDomainOnly ? 'Public Domain & Open Cinema' : 'Cinema & Features'}
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-2 max-w-2xl leading-relaxed">
          {publicDomainOnly
            ? 'Access fully authorized public domain works and Creative Commons animations free of charge with complete statutory copyright compliance.'
            : 'Explore full restored cinematic features, open-source film foundation releases, and official promotional festival previews.'}
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 mb-8 bg-[#111722] p-4 rounded-2xl border border-white/5">
        {/* Genre Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto no-scrollbar pb-1 md:pb-0">
          {genres.map((g) => (
            <button
              key={g}
              onClick={() => setSelectedGenre(g)}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                selectedGenre === g
                  ? 'bg-[#E5093A] text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              {g}
            </button>
          ))}
        </div>

        {/* License Selector & Search */}
        <div className="flex items-center gap-3">
          {!publicDomainOnly && (
            <select
              value={selectedLicense}
              onChange={(e) => setSelectedLicense(e.target.value)}
              className="bg-[#080B12] text-xs text-slate-200 border border-white/10 rounded-lg px-3 py-2 pr-8 focus:outline-none focus:border-[#E5093A]"
            >
              <option value="All">All Licenses</option>
              <option value="PUBLIC_DOMAIN">Public Domain Only</option>
              <option value="OPEN_LICENSE">Open Creative Commons</option>
            </select>
          )}

          <div className="relative flex-1 sm:w-60">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by title, actor, genre..."
              className="w-full bg-[#080B12] text-xs text-white pl-8 pr-3 py-2 rounded-lg border border-white/10 focus:outline-none focus:border-[#E5093A] placeholder:text-slate-500"
            />
          </div>
        </div>
      </div>

      {/* Movies Grid */}
      {filteredMovies.length > 0 ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 sm:gap-6">
          {filteredMovies.map((movie) => (
            <div key={movie.id} className="w-full">
              <MediaCard
                movie={movie}
                onPlay={onPlayMovie}
                onOpenDetails={onOpenDetails}
                aspectRatio="poster"
              />
            </div>
          ))}
        </div>
      ) : (
        <div className="py-20 text-center bg-[#111722]/40 rounded-2xl border border-white/5 p-8">
          <Film className="w-10 h-10 text-slate-600 mx-auto mb-3" />
          <h3 className="text-base font-semibold text-white">No movies matched your selection</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
            Try resetting your genre filter or search query.
          </p>
          <button
            onClick={() => {
              setSelectedGenre('All');
              setSelectedLicense(publicDomainOnly ? 'PUBLIC_DOMAIN' : 'All');
              setSearchQuery('');
            }}
            className="mt-4 px-4 py-2 rounded-lg bg-white/10 text-xs font-semibold text-white hover:bg-white/20 transition-colors"
          >
            Reset Filters
          </button>
        </div>
      )}

      {/* Legal & Attribution Banner */}
      <div className="mt-12 p-4 rounded-xl bg-white/5 border border-white/5 flex items-center gap-3 text-xs text-slate-400">
        <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
        <p>
          Aether Stream hosts no pirated commercial releases. Every stream source is audited against the USA Copyright Office records or Open Source Foundation deeds.
        </p>
      </div>
    </div>
  );
};
