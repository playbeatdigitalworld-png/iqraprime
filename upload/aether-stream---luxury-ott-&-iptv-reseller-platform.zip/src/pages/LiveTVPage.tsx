import React, { useState, useMemo } from 'react';
import type { Channel } from '../types/index.js';
import { ChannelCard } from '../components/common/ChannelCard.js';
import { Radio, Search, Filter, ShieldCheck } from 'lucide-react';

interface LiveTVPageProps {
  channels: Channel[];
  onPlayChannel: (channel: Channel) => void;
}

export const LiveTVPage: React.FC<LiveTVPageProps> = ({ channels, onPlayChannel }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedCountry, setSelectedCountry] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const categories = ['All', 'News', 'Science & Tech', 'Sports', 'Culture'];
  const countries = ['All', 'United States', 'Germany', 'France', 'Pakistan', 'European Union'];

  const filteredChannels = useMemo(() => {
    return channels.filter((c) => {
      if (!c.enabled) return false;
      const matchesCategory = selectedCategory === 'All' || c.category === selectedCategory;
      const matchesCountry = selectedCountry === 'All' || c.country.toLowerCase().includes(selectedCountry.toLowerCase());
      const matchesSearch =
        !searchQuery ||
        c.channelName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.language.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesCountry && matchesSearch;
    });
  }, [channels, selectedCategory, selectedCountry, searchQuery]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-16 min-h-screen">
      {/* Page Header */}
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-2 text-xs font-semibold text-[#E5093A] uppercase tracking-wider">
          <Radio className="w-3.5 h-3.5 animate-pulse" />
          <span>Free-to-Air Public Broadcasts</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white font-display tracking-tight">
          Live TV Guide
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-2 max-w-2xl leading-relaxed">
          Stream authorized live feeds from international public broadcasters and free-to-air statutory networks.
          Each stream operates with verified direct playback licenses.
        </p>
      </div>

      {/* Filter and Search Controls Bar */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 mb-8 bg-[#111722] p-4 rounded-2xl border border-white/5">
        {/* Category Segmented Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto no-scrollbar pb-1 md:pb-0">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                selectedCategory === cat
                  ? 'bg-[#E5093A] text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Country & Search Filters */}
        <div className="flex items-center gap-3">
          {/* Country select */}
          <div className="relative">
            <select
              value={selectedCountry}
              onChange={(e) => setSelectedCountry(e.target.value)}
              className="bg-[#080B12] text-xs text-slate-200 border border-white/10 rounded-lg px-3 py-2 pr-8 focus:outline-none focus:border-[#E5093A]"
            >
              {countries.map((c) => (
                <option key={c} value={c}>
                  {c === 'All' ? 'All Territories' : c}
                </option>
              ))}
            </select>
          </div>

          {/* Search input */}
          <div className="relative flex-1 sm:w-60">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search channels..."
              className="w-full bg-[#080B12] text-xs text-white pl-8 pr-3 py-2 rounded-lg border border-white/10 focus:outline-none focus:border-[#E5093A] placeholder:text-slate-500"
            />
          </div>
        </div>
      </div>

      {/* Channels Grid */}
      {filteredChannels.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredChannels.map((channel) => (
            <ChannelCard
              key={channel.id}
              channel={channel}
              onPlay={onPlayChannel}
            />
          ))}
        </div>
      ) : (
        <div className="py-20 text-center bg-[#111722]/40 rounded-2xl border border-white/5 p-8">
          <Radio className="w-10 h-10 text-slate-600 mx-auto mb-3" />
          <h3 className="text-base font-semibold text-white">No channels matched your filters</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
            Try adjusting your search criteria or reset category filters to view all available broadcasts.
          </p>
          <button
            onClick={() => {
              setSelectedCategory('All');
              setSelectedCountry('All');
              setSearchQuery('');
            }}
            className="mt-4 px-4 py-2 rounded-lg bg-white/10 text-xs font-semibold text-white hover:bg-white/20 transition-colors"
          >
            Reset Filters
          </button>
        </div>
      )}

      {/* Compliance Notice */}
      <div className="mt-12 p-4 rounded-xl bg-white/5 border border-white/5 flex items-center gap-3 text-xs text-slate-400">
        <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
        <p>
          Every broadcast on this page is transmitted strictly via legitimate free-to-air distribution links or statutory public service APIs.
          No unauthorized IPTV scrapers are utilized.
        </p>
      </div>
    </div>
  );
};
