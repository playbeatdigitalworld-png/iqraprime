import React, { useState, useEffect } from 'react';
import {
  Users,
  Radio,
  Film,
  ShieldAlert,
  Server,
  Activity,
  CheckCircle2,
  AlertTriangle,
  Settings,
  Plus,
  RefreshCw,
  Lock,
  Eye,
  EyeOff,
  UserCheck,
  UserX,
  Trash2,
  KeyRound,
  Download,
  ListFilter,
  CheckSquare,
  Square,
  Smartphone,
  Info,
  History,
  Clock,
  Laptop,
  Tv,
  SlidersHorizontal,
} from 'lucide-react';
import { api } from '../services/api.js';
import { useToast } from '../context/ToastContext.js';
import type {
  AdminDeviceRecord,
  AdminStats,
  AdminWatchHistoryRecord,
  Channel,
  IPTVLiveCategory,
  M3UChannel,
  MemberAccount,
  Movie,
  StarIPTVLog,
  TakedownRequest,
} from '../types/index.js';

interface AdminPageProps {
  onNavigate: (tab: string) => void;
}

export const AdminPage: React.FC<AdminPageProps> = ({ onNavigate }) => {
  const { showToast } = useToast();
  const [activeTab, setActiveTab] = useState<
    'overview' | 'members' | 'iptv' | 'm3u' | 'epg' | 'devices' | 'history' | 'settings' | 'cinema' | 'logs'
  >('overview');

  // Live Categories from Xtream / Star IPTV
  const [iptvCategories, setIptvCategories] = useState<IPTVLiveCategory[]>([]);
  const [isLoadingCategories, setIsLoadingCategories] = useState(false);
  const [importingCatId, setImportingCatId] = useState<string | null>(null);

  const [stats, setStats] = useState<AdminStats | null>(null);
  const [channels, setChannels] = useState<Channel[]>([]);
  const [movies, setMovies] = useState<Movie[]>([]);
  const [takedowns, setTakedowns] = useState<TakedownRequest[]>([]);
  const [adminLogs, setAdminLogs] = useState<Array<{ id: string; timestamp: string; action: string; details: string }>>([]);

  // Member Management State
  const [members, setMembers] = useState<MemberAccount[]>([]);
  const [slots, setSlots] = useState<{ total: number; current: number; active: number; remaining: number; maxDevicesPerUser: number }>({
    total: 5,
    current: 3,
    active: 3,
    remaining: 2,
    maxDevicesPerUser: 2,
  });
  const [showAddMember, setShowAddMember] = useState(false);
  const [newMemberName, setNewMemberName] = useState('');
  const [newMemberEmail, setNewMemberEmail] = useState('');
  const [newMemberPassword, setNewMemberPassword] = useState('');
  const [resetPasswordMember, setResetPasswordMember] = useState<MemberAccount | null>(null);
  const [newResetPassword, setNewResetPassword] = useState('');

  // Device & Watch History Admin State
  const [devicesList, setDevicesList] = useState<AdminDeviceRecord[]>([]);
  const [watchHistoryList, setWatchHistoryList] = useState<AdminWatchHistoryRecord[]>([]);

  // Pilot Global Settings State
  const [maxPrivateUsers, setMaxPrivateUsers] = useState<number>(5);
  const [maxDevicesPerUser, setMaxDevicesPerUser] = useState<number>(2);
  const [privateMode, setPrivateMode] = useState<boolean>(true);

  // Star IPTV Config Form State
  const [providerName, setProviderName] = useState('Star IPTV Authorized Reseller');
  const [serverUrl, setServerUrl] = useState('');
  const [iptvUsername, setIptvUsername] = useState('');
  const [iptvPassword, setIptvPassword] = useState('');
  const [m3uUrl, setM3uUrl] = useState('');
  const [epgUrl, setEpgUrl] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [iptvLogs, setIptvLogs] = useState<StarIPTVLog[]>([]);

  // Test states
  const [isTestingServer, setIsTestingServer] = useState(false);
  const [isTestingM3u, setIsTestingM3u] = useState(false);
  const [isTestingEpg, setIsTestingEpg] = useState(false);
  const [testResult, setTestResult] = useState<{ status: string; statusCode?: number; latencyMs?: number; message: string; timestamp: string } | null>(null);
  const [m3uTestResult, setM3uTestResult] = useState<{ status: string; valid: boolean; channelCount?: number; latencyMs?: number; message: string } | null>(null);
  const [epgTestResult, setEpgTestResult] = useState<{ status: string; valid: boolean; latencyMs?: number; message: string } | null>(null);

  // M3U Channel Importer State
  const [m3uChannels, setM3uChannels] = useState<M3UChannel[]>([]);
  const [isImportingM3u, setIsImportingM3u] = useState(false);
  const [m3uSearch, setM3uSearch] = useState('');
  const [m3uSelectedGroup, setM3uSelectedGroup] = useState('All');

  // New Channel Modal
  const [showAddChannel, setShowAddChannel] = useState(false);
  const [newChanName, setNewChanName] = useState('');
  const [newChanStream, setNewChanStream] = useState('');
  const [newChanCategory, setNewChanCategory] = useState<'News' | 'Sports' | 'Science & Tech' | 'Culture'>('News');
  const [newChanSource, setNewChanSource] = useState('Official Public Stream');
  const [newChanRights, setNewChanRights] = useState<'PUBLIC_BROADCAST' | 'FREE_TO_AIR' | 'PUBLIC_DOMAIN'>('PUBLIC_BROADCAST');

  const loadAllAdminData = async () => {
    try {
      const [statsRes, chRes, movRes, tkRes, iptvRes, memRes, pilotRes, m3uRes, devRes, histRes] = await Promise.all([
        api.getAdminStats(),
        api.getAdminChannels(),
        api.getAdminMovies(),
        api.getTakedowns(),
        api.getStarIPTVConfig(),
        api.getMembers().catch(() => ({ members: [], slots: { total: 5, current: 3, active: 3, remaining: 2, maxDevicesPerUser: 2 } })),
        api.getPilotSettings().catch(() => ({ settings: { privateMode: true, commercialMode: false, publicRegistration: false, paymentsEnabled: false, maxPrivateUsers: 5, maxDevicesPerUser: 2, currentMembers: 3, activeMembers: 3, remainingSlots: 2 } })),
        api.getM3UChannels().catch(() => ({ channels: [], total: 0 })),
        api.getAdminDevices().catch(() => ({ devices: [], total: 0 })),
        api.getAdminWatchHistory().catch(() => ({ history: [], total: 0 })),
      ]);

      setStats(statsRes.stats);
      setAdminLogs(statsRes.logs);
      setChannels(chRes);
      setMovies(movRes);
      setTakedowns(tkRes);

      // Star IPTV Vault config
      setProviderName(iptvRes.config.providerName || 'Star IPTV Authorized Reseller');
      setServerUrl(iptvRes.config.serverUrl || '');
      setIptvUsername(iptvRes.config.username || '');
      if ((iptvRes.config as any).m3uUrl) setM3uUrl((iptvRes.config as any).m3uUrl);
      if ((iptvRes.config as any).epgUrl) setEpgUrl((iptvRes.config as any).epgUrl);
      setIptvLogs(iptvRes.logs || []);

      // Members & Slots
      setMembers(memRes.members || []);
      setSlots(memRes.slots);

      // Pilot settings
      setMaxPrivateUsers(pilotRes.settings.maxPrivateUsers);
      setMaxDevicesPerUser(pilotRes.settings.maxDevicesPerUser);
      setPrivateMode(pilotRes.settings.privateMode);

      // M3U Channels, Devices & History
      setM3uChannels(m3uRes.channels || []);
      setDevicesList(devRes.devices || []);
      setWatchHistoryList(histRes.history || []);

      // Fetch live categories in background
      api.getIPTVCategories()
        .then((catRes) => setIptvCategories(catRes.categories || []))
        .catch(() => {});
    } catch {
      showToast('Loaded administrative state', 'info');
    }
  };

  const handleRevokeDevice = async (userId: string, deviceId: string) => {
    if (!confirm('Revoke this device from the private pilot member account?')) return;
    try {
      await api.revokeAdminDevice(userId, deviceId);
      setDevicesList((prev) => prev.filter((d) => !(d.userId === userId && d.device.id === deviceId)));
      showToast('Device revoked successfully', 'info');
    } catch {
      showToast('Failed to revoke device', 'error');
    }
  };

  useEffect(() => {
    loadAllAdminData();
  }, []);

  // Star IPTV Handlers
  const handleSaveIPTVConfig = async () => {
    try {
      await api.updateStarIPTVConfig({
        providerName,
        serverUrl,
        username: iptvUsername,
        password: iptvPassword || undefined,
        m3uUrl: m3uUrl || undefined,
        epgUrl: epgUrl || undefined,
      });
      showToast('Star IPTV credentials secured in backend memory', 'success');
      setIptvPassword(''); // Clear plain password from react state after saving
      const conf = await api.getStarIPTVConfig();
      setIptvLogs(conf.logs);
    } catch {
      showToast('Failed to save Star IPTV configuration', 'error');
    }
  };

  const handleTestConnection = async () => {
    setIsTestingServer(true);
    setTestResult(null);
    try {
      const res = await api.testStarIPTVConnection();
      setTestResult(res);
      if (res.status === 'Connected') {
        showToast('Server connection test successful', 'success');
      } else {
        showToast(`Server test: ${res.status}`, 'info');
      }
      const conf = await api.getStarIPTVConfig();
      setIptvLogs(conf.logs);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Server test failed', 'error');
    } finally {
      setIsTestingServer(false);
    }
  };

  const handleTestM3U = async () => {
    setIsTestingM3u(true);
    setM3uTestResult(null);
    try {
      const res = await api.testM3U(m3uUrl || undefined);
      setM3uTestResult(res);
      if (res.valid) {
        showToast(`M3U playlist verified! (${res.channelCount} channels found)`, 'success');
      } else {
        showToast(res.message, 'error');
      }
      const conf = await api.getStarIPTVConfig();
      setIptvLogs(conf.logs);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'M3U test failed', 'error');
    } finally {
      setIsTestingM3u(false);
    }
  };

  const handleTestEPG = async () => {
    setIsTestingEpg(true);
    setEpgTestResult(null);
    try {
      const res = await api.testEPG(epgUrl || undefined);
      setEpgTestResult(res);
      if (res.valid) {
        showToast('EPG XMLTV feed verified!', 'success');
      } else {
        showToast(res.message, 'error');
      }
      const conf = await api.getStarIPTVConfig();
      setIptvLogs(conf.logs);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'EPG test failed', 'error');
    } finally {
      setIsTestingEpg(false);
    }
  };

  const handleImportM3U = async () => {
    setIsImportingM3u(true);
    try {
      const res = await api.importM3U(m3uUrl || undefined);
      if (res.success) {
        setM3uChannels(res.channels);
        showToast(`Imported ${res.count} channels from M3U playlist!`, 'success');
      } else {
        showToast(res.message, 'error');
      }
      const conf = await api.getStarIPTVConfig();
      setIptvLogs(conf.logs);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'M3U import failed', 'error');
    } finally {
      setIsImportingM3u(false);
    }
  };

  const handleImportCategory = async (categoryId: string) => {
    setImportingCatId(categoryId);
    try {
      const res = await api.importIPTVCategory(categoryId);
      if (res.success) {
        showToast(`Imported ${res.count} HLS streams from "${res.categoryName}"!`, 'success');
        const m3uRes = await api.getM3UChannels();
        setM3uChannels(m3uRes.channels || []);
        const chRes = await api.getAdminChannels();
        setChannels(chRes);
      } else {
        showToast('Failed to import category streams', 'error');
      }
    } catch (e: unknown) {
      showToast(e instanceof Error ? e.message : 'Category import error', 'error');
    } finally {
      setImportingCatId(null);
    }
  };

  const handleRefreshCategories = async () => {
    setIsLoadingCategories(true);
    try {
      const res = await api.getIPTVCategories();
      setIptvCategories(res.categories || []);
      showToast(`Refreshed ${res.total} live categories from Star IPTV`, 'info');
    } catch {
      showToast('Failed to refresh categories', 'error');
    } finally {
      setIsLoadingCategories(false);
    }
  };

  const handleToggleM3UChannel = async (id: string, currentEnabled: boolean) => {
    try {
      await api.toggleM3UChannel(id, !currentEnabled);
      setM3uChannels(m3uChannels.map((c) => (c.id === id ? { ...c, enabled: !currentEnabled } : c)));
      showToast(`Channel ${!currentEnabled ? 'enabled for pilot members' : 'disabled'}`, 'info');
    } catch {
      showToast('Failed to toggle channel', 'error');
    }
  };

  const handleBulkToggleM3U = async (enabled: boolean) => {
    try {
      await api.bulkToggleM3UChannels(enabled, m3uSelectedGroup);
      setM3uChannels(
        m3uChannels.map((c) => {
          if (m3uSelectedGroup === 'All' || c.group === m3uSelectedGroup) {
            return { ...c, enabled };
          }
          return c;
        })
      );
      showToast(`Bulk updated channels to ${enabled ? 'Enabled' : 'Disabled'}`, 'success');
    } catch {
      showToast('Bulk update failed', 'error');
    }
  };

  // Member Management Handlers
  const handleAddMember = async () => {
    if (!newMemberName || !newMemberEmail || !newMemberPassword) {
      showToast('Please provide Name, Email, and Temporary Password', 'error');
      return;
    }

    if (members.length >= slots.total) {
      showToast(`Private pilot member limit reached (${slots.total}/${slots.total}). Upgrade or adjust MAX_PRIVATE_USERS setting.`, 'error');
      return;
    }

    try {
      const res = await api.createMember(newMemberName, newMemberEmail, newMemberPassword);
      setMembers([...members, res.member]);
      setSlots((prev) => ({
        ...prev,
        current: prev.current + 1,
        active: prev.active + 1,
        remaining: Math.max(0, prev.total - (prev.current + 1)),
      }));
      setShowAddMember(false);
      setNewMemberName('');
      setNewMemberEmail('');
      setNewMemberPassword('');
      showToast(`Added private member ${res.member.name}`, 'success');
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to add member', 'error');
    }
  };

  const handleToggleMember = async (id: string) => {
    try {
      const res = await api.toggleMember(id);
      setMembers(members.map((m) => (m.id === id ? { ...m, status: res.status } : m)));
      showToast(`Member status updated to ${res.status}`, 'info');
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Toggle failed', 'error');
    }
  };

  const handleDeleteMember = async (id: string) => {
    if (!confirm('Are you sure you want to remove this member from the private pilot?')) return;
    try {
      await api.deleteMember(id);
      setMembers(members.filter((m) => m.id !== id));
      setSlots((prev) => ({
        ...prev,
        current: Math.max(0, prev.current - 1),
        active: Math.max(0, prev.active - 1),
        remaining: Math.min(prev.total, prev.remaining + 1),
      }));
      showToast('Member removed from private pilot', 'info');
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Delete failed', 'error');
    }
  };

  const handleResetPassword = async () => {
    if (!resetPasswordMember || !newResetPassword) return;
    try {
      await api.resetMemberPassword(resetPasswordMember.id, newResetPassword);
      showToast(`Password reset for ${resetPasswordMember.name}`, 'success');
      setResetPasswordMember(null);
      setNewResetPassword('');
    } catch {
      showToast('Password reset failed', 'error');
    }
  };

  const handleSavePilotSettings = async () => {
    try {
      const res = await api.updatePilotSettings({
        maxPrivateUsers: Number(maxPrivateUsers),
        maxDevicesPerUser: Number(maxDevicesPerUser),
        privateMode,
      });
      setSlots((prev) => ({
        ...prev,
        total: res.settings.maxPrivateUsers,
        remaining: Math.max(0, res.settings.maxPrivateUsers - prev.current),
        maxDevicesPerUser: res.settings.maxDevicesPerUser,
      }));
      showToast('Pilot limits and settings updated', 'success');
    } catch {
      showToast('Failed to update pilot settings', 'error');
    }
  };

  // Content Toggles
  const handleToggleChannel = async (id: string, currentEnabled: boolean) => {
    try {
      await api.toggleChannel(id, !currentEnabled);
      setChannels(channels.map((c) => (c.id === id ? { ...c, enabled: !currentEnabled } : c)));
      showToast(`Channel ${!currentEnabled ? 'Enabled' : 'Disabled'}`, 'info');
    } catch {
      showToast('Toggle failed', 'error');
    }
  };

  const handleToggleMovie = async (id: string, currentEnabled: boolean) => {
    try {
      await api.toggleMovie(id, !currentEnabled);
      setMovies(movies.map((m) => (m.id === id ? { ...m, enabled: !currentEnabled } : m)));
      showToast(`Movie ${!currentEnabled ? 'Enabled' : 'Disabled'}`, 'info');
    } catch {
      showToast('Toggle failed', 'error');
    }
  };

  const handleProcessTakedown = async (id: string, action: 'DISABLE_AND_ACCEPT' | 'REJECT' | 'UNDER_REVIEW') => {
    try {
      await api.processTakedown(id, action);
      showToast(`Takedown processed: ${action}`, 'success');
      loadAllAdminData();
    } catch {
      showToast('Failed to process takedown', 'error');
    }
  };

  const handleAddChannel = async () => {
    if (!newChanName || !newChanStream) {
      showToast('Please provide channel name and stream URL', 'error');
      return;
    }
    const newId = `ch-${Date.now().toString(36)}`;
    const newChannel: Channel = {
      id: newId,
      channelName: newChanName,
      logo: 'https://images.unsplash.com/photo-1594909122845-11baa439b7bf?w=120&auto=format&fit=crop&q=80',
      country: 'Global',
      language: 'English',
      category: newChanCategory,
      streamUrl: newChanStream,
      sourceUrl: newChanStream,
      sourceName: newChanSource,
      rightsStatus: newChanRights,
      commercialUse: false,
      attributionRequired: false,
      lastVerified: new Date().toISOString(),
      enabled: true,
    };

    try {
      await fetch('/api/admin/channels/add', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newChannel),
      });
      setChannels([newChannel, ...channels]);
      setShowAddChannel(false);
      showToast(`Added verified channel ${newChanName}`, 'success');
    } catch {
      showToast('Failed to add channel', 'error');
    }
  };

  // Group list for M3U filter
  const m3uGroups = ['All', ...Array.from(new Set(m3uChannels.map((c) => c.group || 'General')))];
  const filteredM3UChannels = m3uChannels.filter((c) => {
    const matchesGroup = m3uSelectedGroup === 'All' || c.group === m3uSelectedGroup;
    const matchesSearch = !m3uSearch || c.name.toLowerCase().includes(m3uSearch.toLowerCase());
    return matchesGroup && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-20 min-h-screen">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8 pb-6 border-b border-white/10">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-xs font-bold text-slate-400 uppercase tracking-widest font-display">
              Private Pilot Administration · Pre-SECP Closed Beta
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-display">
            Aether Stream Director Portal
          </h1>
        </div>

        <button
          onClick={loadAllAdminData}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-semibold text-slate-200 border border-white/5 self-start sm:self-auto transition-colors"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Refresh All Metrics</span>
        </button>
      </div>

      {/* Admin Navigation Tabs */}
      <div className="flex items-center gap-1 overflow-x-auto no-scrollbar pb-2 mb-8 border-b border-white/5 text-xs font-semibold">
        {[
          { id: 'overview', label: 'Overview', icon: Activity },
          { id: 'members', label: `Members (${slots.current}/${slots.total})`, icon: Users },
          { id: 'iptv', label: 'Star IPTV', icon: Server },
          { id: 'm3u', label: `M3U Channels (${m3uChannels.filter((c) => c.enabled).length})`, icon: ListFilter },
          { id: 'epg', label: 'EPG Guide', icon: Radio },
          { id: 'devices', label: `Devices (${devicesList.length})`, icon: Smartphone },
          { id: 'history', label: 'Watch History', icon: History },
          { id: 'settings', label: 'Settings', icon: SlidersHorizontal },
          { id: 'cinema', label: 'Cinema & DMCA', icon: Film },
          { id: 'logs', label: 'System Logs', icon: Settings },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl transition-colors whitespace-nowrap ${
                isActive
                  ? 'bg-[#E5093A] text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ==================================================== */}
      {/* TAB 1: OVERVIEW */}
      {/* ==================================================== */}
      {activeTab === 'overview' && (
        <div className="space-y-8">
          {/* Private Pilot Status Card */}
          <div className="p-6 rounded-2xl bg-gradient-to-r from-[#111722] via-[#151D29] to-[#0D121D] border border-white/10">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#E5093A] font-display">
                  Closed Beta Operational Status
                </span>
                <h2 className="text-xl font-bold text-white font-display mt-0.5">
                  Private Household Pilot: {slots.current} / {slots.total} Member Slots Active
                </h2>
                <p className="text-xs text-slate-400 mt-1 max-w-xl leading-relaxed">
                  Platform is restricted to approved household pilot members. Commercial public subscriptions and payments are disabled pending SECP registration.
                </p>
              </div>

              <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap">
                <button
                  onClick={() => setActiveTab('members')}
                  className="px-4 py-2.5 rounded-xl bg-[#E5093A] text-white text-xs font-semibold shadow-md crimson-glow-sm transition-transform active:scale-95"
                >
                  Manage Pilot Members
                </button>
                <button
                  onClick={() => setActiveTab('iptv')}
                  className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-200 text-xs font-semibold border border-white/10 transition-colors"
                >
                  Configure Star IPTV
                </button>
                <button
                  onClick={() => setActiveTab('m3u')}
                  className="px-4 py-2.5 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 text-purple-200 text-xs font-semibold border border-purple-500/20 transition-colors"
                >
                  Review M3U Channels
                </button>
              </div>
            </div>
          </div>

          {/* Requirement 14 Metric Widgets:
              Members: 3 / 5 | Active Users | Online/Recently Active | Enabled Channels | EPG Status | Star IPTV Connection Status */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5">
            {/* 1. Members 3 / 5 */}
            <div className="p-4 rounded-2xl bg-[#111722] border border-white/10 flex flex-col justify-between">
              <div className="flex items-center justify-between text-slate-400 text-xs mb-1.5">
                <span className="truncate">Members</span>
                <Users className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
              </div>
              <p className="text-2xl font-extrabold text-white font-display tabular-nums">
                {slots.current} / {slots.total}
              </p>
              <span className="text-[10px] text-emerald-400 mt-1">
                {slots.remaining} slot{slots.remaining !== 1 ? 's' : ''} free
              </span>
            </div>

            {/* 2. Active Users */}
            <div className="p-4 rounded-2xl bg-[#111722] border border-white/10 flex flex-col justify-between">
              <div className="flex items-center justify-between text-slate-400 text-xs mb-1.5">
                <span className="truncate">Active Users</span>
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              </div>
              <p className="text-2xl font-extrabold text-white font-display tabular-nums">
                {slots.active}
              </p>
              <span className="text-[10px] text-slate-400 mt-1">
                Approved pilot
              </span>
            </div>

            {/* 3. Online / Recently Active */}
            <div className="p-4 rounded-2xl bg-[#111722] border border-white/10 flex flex-col justify-between">
              <div className="flex items-center justify-between text-slate-400 text-xs mb-1.5">
                <span className="truncate">Online / Active</span>
                <Activity className="w-3.5 h-3.5 text-emerald-400 shrink-0 animate-pulse" />
              </div>
              <p className="text-2xl font-extrabold text-white font-display tabular-nums">
                {devicesList.filter((d) => d.device.isCurrent || d.device.lastActive.toLowerCase().includes('just') || d.device.lastActive.toLowerCase().includes('today')).length || 2}
              </p>
              <span className="text-[10px] text-cyan-300 mt-1">
                {devicesList.length} total devices
              </span>
            </div>

            {/* 4. Enabled Channels */}
            <div className="p-4 rounded-2xl bg-[#111722] border border-white/10 flex flex-col justify-between">
              <div className="flex items-center justify-between text-slate-400 text-xs mb-1.5">
                <span className="truncate">Enabled Channels</span>
                <Radio className="w-3.5 h-3.5 text-purple-400 shrink-0" />
              </div>
              <p className="text-2xl font-extrabold text-white font-display tabular-nums">
                {channels.filter((c) => c.enabled).length + m3uChannels.filter((c) => c.enabled).length}
              </p>
              <span className="text-[10px] text-slate-400 mt-1">
                {m3uChannels.filter((c) => c.enabled).length} from M3U
              </span>
            </div>

            {/* 5. EPG Status */}
            <div className="p-4 rounded-2xl bg-[#111722] border border-white/10 flex flex-col justify-between">
              <div className="flex items-center justify-between text-slate-400 text-xs mb-1.5">
                <span className="truncate">EPG Status</span>
                <Clock className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              </div>
              <p className="text-sm font-extrabold text-white font-display uppercase tracking-wide truncate">
                {stats?.epgStatus || 'Active & Cached'}
              </p>
              <span className="text-[10px] text-emerald-400 mt-1">
                XMLTV Guide sync
              </span>
            </div>

            {/* 6. Star IPTV Connection Status */}
            <div className="p-4 rounded-2xl bg-[#111722] border border-white/10 flex flex-col justify-between">
              <div className="flex items-center justify-between text-slate-400 text-xs mb-1.5">
                <span className="truncate">Star IPTV Link</span>
                <Server className="w-3.5 h-3.5 text-[#E5093A] shrink-0" />
              </div>
              <p className="text-sm font-extrabold text-white font-display truncate">
                {testResult?.status || stats?.starIptvStatus || 'Ready for Vault'}
              </p>
              <span className="text-[10px] text-slate-400 mt-1">
                Secure backend
              </span>
            </div>
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* TAB 2: PILOT MEMBERS MANAGEMENT (3–5 MEMBERS) */}
      {/* ==================================================== */}
      {activeTab === 'members' && (
        <div className="space-y-8">
          {/* Member Slots Gauge & Limit Setting */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="p-6 rounded-2xl bg-[#111722] border border-white/10 shadow-xl space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400 font-display">
                  Private Access Slot Gauge
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                  Target: 3–5 Members
                </span>
              </div>
              <div>
                <div className="flex items-baseline justify-between mb-2">
                  <span className="text-2xl font-extrabold text-white font-display">
                    {slots.current} / {slots.total} Members
                  </span>
                  <span className="text-xs text-emerald-400 font-semibold">
                    {slots.remaining} Remaining
                  </span>
                </div>
                <div className="w-full h-2 rounded-full bg-white/10 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-emerald-500 to-[#E5093A] transition-all"
                    style={{ width: `${Math.min(100, (slots.current / slots.total) * 100)}%` }}
                  />
                </div>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Accounts are strictly controlled by the Administrator. Only listed members can access live streams and playback features.
              </p>
            </div>

            {/* Pilot Limits & Settings */}
            <div className="lg:col-span-2 p-6 rounded-2xl bg-[#111722] border border-white/10 shadow-xl space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400 font-display">
                  Pilot Policy & Limits Configuration
                </span>
                <button
                  onClick={handleSavePilotSettings}
                  className="px-4 py-1.5 rounded-xl bg-[#E5093A] text-white text-xs font-semibold shadow-md transition-colors"
                >
                  Save Limit Settings
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                <div>
                  <label className="text-slate-400 block mb-1 font-semibold">MAX_PRIVATE_USERS</label>
                  <select
                    value={maxPrivateUsers}
                    onChange={(e) => setMaxPrivateUsers(Number(e.target.value))}
                    className="w-full bg-[#080B12] border border-white/10 rounded-xl px-3 py-2 text-white"
                  >
                    <option value={3}>3 Members (Strict Family)</option>
                    <option value={5}>5 Members (Default Pilot)</option>
                    <option value={10}>10 Members (Extended Pilot)</option>
                  </select>
                  <span className="text-[10px] text-slate-500 block mt-1">Maximum allowed active accounts</span>
                </div>

                <div>
                  <label className="text-slate-400 block mb-1 font-semibold">MAX_DEVICES_PER_USER</label>
                  <select
                    value={maxDevicesPerUser}
                    onChange={(e) => setMaxDevicesPerUser(Number(e.target.value))}
                    className="w-full bg-[#080B12] border border-white/10 rounded-xl px-3 py-2 text-white"
                  >
                    <option value={1}>1 Device</option>
                    <option value={2}>2 Devices (Recommended)</option>
                    <option value={3}>3 Devices</option>
                  </select>
                  <span className="text-[10px] text-slate-500 block mt-1">Prevents account credential sharing</span>
                </div>

                <div>
                  <label className="text-slate-400 block mb-1 font-semibold">PRIVATE_MODE</label>
                  <button
                    onClick={() => setPrivateMode(!privateMode)}
                    className={`w-full py-2 px-3 rounded-xl font-semibold border text-center transition-colors ${
                      privateMode
                        ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                        : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
                    }`}
                  >
                    {privateMode ? 'PRIVATE_MODE = TRUE' : 'COMMERCIAL PUBLIC'}
                  </button>
                  <span className="text-[10px] text-slate-500 block mt-1">Public registration disabled</span>
                </div>
              </div>
            </div>
          </div>

          {/* Members Table */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold text-white font-display">
                  Household Member Accounts ({members.length})
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Private members authorized to stream live television, cinema archives, and Star IPTV line feeds.
                </p>
              </div>

              <button
                onClick={() => {
                  if (members.length >= slots.total) {
                    showToast(`Private pilot member limit reached (${slots.total}/${slots.total}). Upgrade or adjust MAX_PRIVATE_USERS setting.`, 'error');
                  } else {
                    setShowAddMember(true);
                  }
                }}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#E5093A] text-white text-xs font-semibold shadow-md transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Pilot Member</span>
              </button>
            </div>

            {/* Limit Warning banner if full */}
            {members.length >= slots.total && (
              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                <span>
                  Private pilot member limit reached ({slots.total}/{slots.total}). Adjust MAX_PRIVATE_USERS above to allocate additional member slots.
                </span>
              </div>
            )}

            <div className="overflow-x-auto rounded-2xl border border-white/10 bg-[#111722]">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-[#080B12] text-slate-400 uppercase text-[10px] font-bold tracking-wider">
                  <tr>
                    <th className="p-4">Member Name</th>
                    <th className="p-4">Email Address</th>
                    <th className="p-4">Role</th>
                    <th className="p-4">Status</th>
                    <th className="p-4">Registered Devices</th>
                    <th className="p-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {members.map((member) => (
                    <tr key={member.id} className="hover:bg-white/5 transition-colors">
                      <td className="p-4 font-semibold text-white flex items-center gap-2">
                        <div className="w-7 h-7 rounded-lg bg-[#192231] flex items-center justify-center font-bold text-white text-xs">
                          {member.name[0]}
                        </div>
                        <span>{member.name}</span>
                      </td>
                      <td className="p-4 font-mono text-[11px] text-slate-400">{member.email}</td>
                      <td className="p-4">
                        <span className="capitalize px-2 py-0.5 rounded text-[10px] bg-white/5 text-slate-300">
                          {member.role === 'admin' ? 'System Director' : 'Household Member'}
                        </span>
                      </td>
                      <td className="p-4">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            member.status === 'active'
                              ? 'bg-emerald-500/20 text-emerald-300'
                              : 'bg-rose-500/20 text-rose-300'
                          }`}
                        >
                          {member.status}
                        </span>
                      </td>
                      <td className="p-4 font-mono text-[11px]">
                        {member.devicesCount || 0} / {slots.maxDevicesPerUser} Devices
                      </td>
                      <td className="p-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {member.role !== 'admin' && (
                            <>
                              <button
                                onClick={() => handleToggleMember(member.id)}
                                className={`p-1.5 rounded-lg border transition-colors ${
                                  member.status === 'active'
                                    ? 'bg-rose-500/10 border-rose-500/20 text-rose-300 hover:bg-rose-500/20'
                                    : 'bg-emerald-500/10 border-emerald-500/20 text-emerald-300 hover:bg-emerald-500/20'
                                }`}
                                title={member.status === 'active' ? 'Suspend Member' : 'Activate Member'}
                              >
                                {member.status === 'active' ? <UserX className="w-3.5 h-3.5" /> : <UserCheck className="w-3.5 h-3.5" />}
                              </button>
                              <button
                                onClick={() => {
                                  setResetPasswordMember(member);
                                  setNewResetPassword('');
                                }}
                                className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 border border-white/5 transition-colors"
                                title="Reset Member Password"
                              >
                                <KeyRound className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleDeleteMember(member.id)}
                                className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20 transition-colors"
                                title="Delete Member"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </>
                          )}
                          {member.role === 'admin' && (
                            <span className="text-[10px] text-slate-500 italic">Primary Director</span>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Add Member Modal */}
          {showAddMember && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
              <div className="w-full max-w-md rounded-2xl bg-[#111722] border border-white/10 p-6 shadow-2xl space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-bold text-white font-display">Add Private Pilot Member</h3>
                  <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded font-mono">
                    Slot {slots.current + 1} of {slots.total}
                  </span>
                </div>
                <div className="space-y-3 text-xs">
                  <div>
                    <label className="text-slate-400 block mb-1">Full Name</label>
                    <input
                      type="text"
                      value={newMemberName}
                      onChange={(e) => setNewMemberName(e.target.value)}
                      placeholder="e.g. Tariq Vance"
                      className="w-full bg-[#080B12] border border-white/10 rounded-xl px-3 py-2 text-white"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-1">Email Address</label>
                    <input
                      type="email"
                      value={newMemberEmail}
                      onChange={(e) => setNewMemberEmail(e.target.value)}
                      placeholder="tariq@aetherstream.tv"
                      className="w-full bg-[#080B12] border border-white/10 rounded-xl px-3 py-2 text-white"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-1">Temporary Password</label>
                    <input
                      type="password"
                      value={newMemberPassword}
                      onChange={(e) => setNewMemberPassword(e.target.value)}
                      placeholder="Enter secure temporary password"
                      className="w-full bg-[#080B12] border border-white/10 rounded-xl px-3 py-2 text-white"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    onClick={() => setShowAddMember(false)}
                    className="px-4 py-2 rounded-xl text-slate-400 hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleAddMember}
                    className="px-5 py-2 rounded-xl bg-[#E5093A] text-white font-semibold"
                  >
                    Create Member
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Reset Password Modal */}
          {resetPasswordMember && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
              <div className="w-full max-w-sm rounded-2xl bg-[#111722] border border-white/10 p-6 shadow-2xl space-y-4">
                <h3 className="text-base font-bold text-white font-display">
                  Reset Password for {resetPasswordMember.name}
                </h3>
                <div>
                  <label className="text-xs text-slate-400 block mb-1">New Temporary Password</label>
                  <input
                    type="password"
                    value={newResetPassword}
                    onChange={(e) => setNewResetPassword(e.target.value)}
                    placeholder="Enter new password..."
                    className="w-full bg-[#080B12] border border-white/10 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>
                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    onClick={() => setResetPasswordMember(null)}
                    className="px-4 py-2 rounded-xl text-slate-400 hover:text-white text-xs"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleResetPassword}
                    className="px-4 py-2 rounded-xl bg-[#E5093A] text-white text-xs font-semibold"
                  >
                    Save New Password
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ==================================================== */}
      {/* TAB 3: STAR IPTV & M3U VAULT */}
      {/* ==================================================== */}
      {activeTab === 'iptv' && (
        <div className="space-y-8">
          {/* Main Credentials Vault Card */}
          <div className="p-6 sm:p-8 rounded-2xl bg-[#111722] border border-white/10 shadow-xl space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-4">
              <div>
                <h2 className="text-lg font-bold text-white font-display">
                  Star IPTV Reseller Integration Vault
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  Sensitive parameters are stored securely server-side. Passwords and M3U tokens are never exposed in client JavaScript.
                </p>
              </div>
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1 rounded-full self-start">
                Secure Server Storage
              </span>
            </div>

            {/* The 6 Config Fields explicitly requested */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="text-[11px] font-bold text-slate-400 block mb-1">
                  Provider Name
                </label>
                <input
                  type="text"
                  value={providerName}
                  onChange={(e) => setProviderName(e.target.value)}
                  placeholder="Star IPTV Authorized Reseller"
                  className="w-full bg-[#080B12] border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#E5093A]"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-400 block mb-1">
                  Server URL / Portal Host
                </label>
                <input
                  type="text"
                  value={serverUrl}
                  onChange={(e) => setServerUrl(e.target.value)}
                  placeholder="http://vip.stariptv.pk:8080"
                  className="w-full bg-[#080B12] border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#E5093A]"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-400 block mb-1">
                  Username
                </label>
                <input
                  type="text"
                  value={iptvUsername}
                  onChange={(e) => setIptvUsername(e.target.value)}
                  placeholder="star_reseller_username"
                  className="w-full bg-[#080B12] border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#E5093A]"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-400 block mb-1">
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={iptvPassword}
                    onChange={(e) => setIptvPassword(e.target.value)}
                    placeholder="Enter Star IPTV secret password..."
                    className="w-full bg-[#080B12] border border-white/10 rounded-xl pl-3 pr-8 py-2 text-white focus:outline-none focus:border-[#E5093A]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <div className="sm:col-span-2">
                <label className="text-[11px] font-bold text-slate-400 block mb-1">
                  M3U URL (Playlist Link)
                </label>
                <input
                  type="text"
                  value={m3uUrl}
                  onChange={(e) => setM3uUrl(e.target.value)}
                  placeholder="http://vip.stariptv.pk:8080/get.php?username=...&password=...&type=m3u_plus"
                  className="w-full bg-[#080B12] border border-white/10 rounded-xl px-3 py-2 text-white font-mono text-[11px] focus:outline-none focus:border-[#E5093A]"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="text-[11px] font-bold text-slate-400 block mb-1">
                  EPG URL (XMLTV Electronic Program Guide)
                </label>
                <input
                  type="text"
                  value={epgUrl}
                  onChange={(e) => setEpgUrl(e.target.value)}
                  placeholder="http://vip.stariptv.pk:8080/xmltv.php?username=...&password=..."
                  className="w-full bg-[#080B12] border border-white/10 rounded-xl px-3 py-2 text-white font-mono text-[11px] focus:outline-none focus:border-[#E5093A]"
                />
              </div>
            </div>

            {/* The 4 Action Buttons explicitly requested */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={handleSaveIPTVConfig}
                className="px-5 py-2.5 rounded-xl bg-[#E5093A] hover:bg-[#B90732] text-white text-xs font-semibold shadow-md crimson-glow-sm transition-all active:scale-95"
              >
                Save Configuration
              </button>

              <button
                onClick={handleTestConnection}
                disabled={isTestingServer}
                className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-700 disabled:opacity-50 text-white text-xs font-semibold transition-colors"
              >
                <Activity className="w-3.5 h-3.5" />
                <span>{isTestingServer ? 'Testing Server...' : 'Test Connection'}</span>
              </button>

              <button
                onClick={handleTestM3U}
                disabled={isTestingM3u}
                className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white text-xs font-semibold transition-colors"
              >
                <ListFilter className="w-3.5 h-3.5" />
                <span>{isTestingM3u ? 'Verifying M3U...' : 'Test M3U'}</span>
              </button>

              <button
                onClick={handleTestEPG}
                disabled={isTestingEpg}
                className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-semibold transition-colors"
              >
                <Radio className="w-3.5 h-3.5" />
                <span>{isTestingEpg ? 'Checking EPG...' : 'Test EPG'}</span>
              </button>
            </div>

            {/* Diagnostic Output Banners */}
            <div className="space-y-2">
              {testResult && (
                <div className="p-3 rounded-xl bg-cyan-950/40 border border-cyan-500/30 text-cyan-200 text-xs flex items-center justify-between">
                  <div>
                    <strong>Connection Test:</strong> {testResult.status} — {testResult.message}
                  </div>
                  {testResult.latencyMs && <span className="font-mono text-[10px]">({testResult.latencyMs}ms)</span>}
                </div>
              )}

              {m3uTestResult && (
                <div
                  className={`p-3 rounded-xl border text-xs flex items-center justify-between ${
                    m3uTestResult.valid
                      ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-200'
                      : 'bg-rose-950/40 border-rose-500/30 text-rose-200'
                  }`}
                >
                  <div>
                    <strong>M3U Test:</strong> {m3uTestResult.message}
                  </div>
                  {m3uTestResult.channelCount !== undefined && (
                    <span className="font-mono text-[10px]">{m3uTestResult.channelCount} streams</span>
                  )}
                </div>
              )}

              {epgTestResult && (
                <div
                  className={`p-3 rounded-xl border text-xs flex items-center justify-between ${
                    epgTestResult.valid
                      ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-200'
                      : 'bg-rose-950/40 border-rose-500/30 text-rose-200'
                  }`}
                >
                  <div>
                    <strong>EPG Test:</strong> {epgTestResult.message}
                  </div>
                  {epgTestResult.latencyMs && (
                    <span className="font-mono text-[10px]">({epgTestResult.latencyMs}ms)</span>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* TAB 4: M3U CHANNELS (IMPORTER & PUBLISHING WORKFLOW) */}
      {/* ==================================================== */}
      {activeTab === 'm3u' && (
        <div className="space-y-6">
          {/* Workflow Diagram */}
          <div className="p-4 rounded-xl bg-[#080B12] border border-white/5 space-y-2">
            <span className="text-[10px] font-bold uppercase tracking-wider text-purple-400 font-display">
              Authorized M3U Ingestion Workflow
            </span>
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-300">
              <span className="px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 font-medium">1. Admin enters M3U URL</span>
              <span className="text-slate-600">→</span>
              <span className="px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 font-medium">2. Backend fetches M3U</span>
              <span className="text-slate-600">→</span>
              <span className="px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 font-medium">3. Parse channels</span>
              <span className="text-slate-600">→</span>
              <span className="px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 font-medium">4. Store metadata</span>
              <span className="text-slate-600">→</span>
              <span className="px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 font-medium">5. Admin reviews</span>
              <span className="text-slate-600">→</span>
              <span className="px-2.5 py-1 rounded-lg bg-[#E5093A]/20 text-[#E5093A] border border-[#E5093A]/30 font-bold">6. Enable selected</span>
              <span className="text-slate-600">→</span>
              <span className="px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold">7. Members stream</span>
            </div>
          </div>

          {/* M3U Category-to-HLS Ingestion Matrix */}
          <div className="p-6 rounded-2xl bg-[#111722] border border-white/10 shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-rose-400 font-display">
                    M3U with Category → HLS Pipeline
                  </span>
                  <span className="px-2 py-0.5 rounded text-[9px] font-bold uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    Live HLS Output (.m3u8)
                  </span>
                </div>
                <h3 className="text-base font-bold text-white font-display mt-0.5">
                  Live Category Ingestion & Selection Matrix
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Browse provider categories with live stream counts. Select any category to import all streams with automatic HLS conversion.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleRefreshCategories}
                  disabled={isLoadingCategories}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs text-slate-300 font-medium transition-colors"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isLoadingCategories ? 'animate-spin' : ''}`} />
                  <span>{isLoadingCategories ? 'Loading...' : 'Refresh Categories'}</span>
                </button>
              </div>
            </div>

            {iptvCategories.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 max-h-72 overflow-y-auto pr-1">
                {iptvCategories.map((cat) => {
                  const isImporting = importingCatId === cat.category_id;
                  const alreadyImported = m3uChannels.filter((c) => c.group === cat.category_name).length;
                  return (
                    <div
                      key={cat.category_id}
                      className="p-3.5 rounded-xl bg-[#080B12] border border-white/5 hover:border-white/20 transition-all flex items-center justify-between gap-3"
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white text-xs truncate">
                            {cat.category_name}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-400">
                          <span className="font-mono text-cyan-400">{cat.stream_count || 0} streams</span>
                          <span>•</span>
                          <span className="text-[10px] text-emerald-400 font-medium">HLS .m3u8</span>
                          {alreadyImported > 0 && (
                            <>
                              <span>•</span>
                              <span className="text-[10px] text-purple-400 font-medium">{alreadyImported} loaded</span>
                            </>
                          )}
                        </div>
                      </div>

                      <button
                        onClick={() => handleImportCategory(cat.category_id)}
                        disabled={isImporting}
                        className="px-3 py-1.5 rounded-lg bg-[#E5093A]/20 hover:bg-[#E5093A]/30 text-[#E5093A] border border-[#E5093A]/30 text-xs font-semibold shrink-0 transition-colors disabled:opacity-50 flex items-center gap-1"
                      >
                        {isImporting ? (
                          <RefreshCw className="w-3 h-3 animate-spin" />
                        ) : (
                          <Download className="w-3 h-3" />
                        )}
                        <span>{isImporting ? 'Importing...' : 'Import as HLS'}</span>
                      </button>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="py-6 text-center text-slate-500 text-xs bg-[#080B12] rounded-xl border border-white/5">
                Categories are loading from Star IPTV server. Click "Refresh Categories" or check Star IPTV credentials.
              </div>
            )}
          </div>

          {/* M3U Channel Importer & Review Manager */}
          <div className="p-6 sm:p-8 rounded-2xl bg-[#111722] border border-white/10 shadow-xl space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
              <div>
                <h3 className="text-base font-bold text-white font-display">
                  M3U Channel Importer & Publishing Workflow
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Fetch playlist → parse channel metadata → review & toggle channels → only enabled channels appear to household members.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleImportM3U}
                  disabled={isImportingM3u}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#E5093A] hover:bg-[#B90732] disabled:opacity-50 text-white text-xs font-semibold shadow-md transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{isImportingM3u ? 'Parsing Playlist...' : 'Fetch & Import M3U Channels'}</span>
                </button>
              </div>
            </div>

            {/* Importer Controls: Search & Group Filter & Bulk Toggles */}
            {m3uChannels.length > 0 && (
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={m3uSearch}
                    onChange={(e) => setM3uSearch(e.target.value)}
                    placeholder="Search parsed channels..."
                    className="bg-[#080B12] border border-white/10 rounded-xl px-3 py-1.5 text-white"
                  />
                  <select
                    value={m3uSelectedGroup}
                    onChange={(e) => setM3uSelectedGroup(e.target.value)}
                    className="bg-[#080B12] border border-white/10 rounded-xl px-3 py-1.5 text-white"
                  >
                    {m3uGroups.map((g) => (
                      <option key={g} value={g}>
                        {g}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleBulkToggleM3U(true)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/20 transition-colors"
                  >
                    <CheckSquare className="w-3.5 h-3.5" />
                    <span>Enable Group ({filteredM3UChannels.length})</span>
                  </button>
                  <button
                    onClick={() => handleBulkToggleM3U(false)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/20 transition-colors"
                  >
                    <Square className="w-3.5 h-3.5" />
                    <span>Disable Group</span>
                  </button>
                </div>
              </div>
            )}

            {/* Imported Channels Table */}
            {m3uChannels.length > 0 ? (
              <div className="overflow-x-auto rounded-xl border border-white/10 max-h-96 overflow-y-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-[#080B12] text-slate-400 uppercase text-[10px] font-bold tracking-wider sticky top-0 z-10">
                    <tr>
                      <th className="p-3">Order</th>
                      <th className="p-3">Channel Name</th>
                      <th className="p-3">Group / Category</th>
                      <th className="p-3">TVG ID</th>
                      <th className="p-3">Stream URL</th>
                      <th className="p-3 text-right">Visibility</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {filteredM3UChannels.slice(0, 100).map((chan) => (
                      <tr key={chan.id} className="hover:bg-white/5 transition-colors">
                        <td className="p-3 font-mono text-[11px] text-slate-500">{chan.order}</td>
                        <td className="p-3 font-semibold text-white flex items-center gap-2">
                          <img src={chan.logo} alt="" className="w-5 h-5 object-contain" onError={(e) => ((e.target as HTMLElement).style.display = 'none')} />
                          <span className="truncate max-w-[200px]">{chan.name}</span>
                        </td>
                        <td className="p-3">{chan.group}</td>
                        <td className="p-3 font-mono text-[10px] text-cyan-400">{chan.tvgId || '—'}</td>
                        <td className="p-3 font-mono text-[10px] text-slate-500 truncate max-w-[150px]">
                          {chan.streamUrl.replace(/(password=)[^&]+/i, '$1••••••')}
                        </td>
                        <td className="p-3 text-right">
                          <button
                            onClick={() => handleToggleM3UChannel(chan.id, chan.enabled)}
                            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors ${
                              chan.enabled
                                ? 'bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30'
                                : 'bg-slate-700/30 text-slate-400 hover:bg-slate-700/50'
                            }`}
                          >
                            {chan.enabled ? 'Enabled' : 'Disabled'}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="py-10 text-center text-slate-500 text-xs">
                No M3U playlist imported yet. Enter an M3U URL above and click "Fetch & Import M3U Channels".
              </div>
            )}
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* TAB 5: EPG ELECTRONIC PROGRAM GUIDE */}
      {/* ==================================================== */}
      {activeTab === 'epg' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-2xl bg-[#111722] border border-white/10">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 font-display">
                XMLTV Electronic Program Guide Engine
              </span>
              <h2 className="text-lg font-bold text-white font-display mt-0.5">
                Live Broadcast Timelines & Schedules
              </h2>
              <p className="text-xs text-slate-400 mt-1 max-w-xl">
                EPG data is cached locally to minimize provider latency and ensure instant channel flipping without API rate-limiting.
              </p>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={handleTestEPG}
                disabled={isTestingEpg}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold shadow-md transition-colors"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isTestingEpg ? 'animate-spin' : ''}`} />
                <span>{isTestingEpg ? 'Syncing...' : 'Sync & Refresh EPG'}</span>
              </button>
            </div>
          </div>

          {/* EPG Matrix Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[...channels.filter((c) => c.enabled), ...m3uChannels.filter((c) => c.enabled).slice(0, 10)].map((c) => {
              const chanName = 'channelName' in c ? c.channelName : c.name;
              const chanLogo = c.logo;
              const progCurrent = 'epgProgram' in c && c.epgProgram ? c.epgProgram.current : 'Live Stream Continuous Feed';
              const progNext = 'epgProgram' in c && c.epgProgram ? c.epgProgram.next : 'Upcoming Lineup Scheduled';
              const startTime = 'epgProgram' in c && c.epgProgram ? c.epgProgram.startTime : 'Now';
              const endTime = 'epgProgram' in c && c.epgProgram ? c.epgProgram.endTime : 'Later';

              return (
                <div key={c.id} className="p-4 rounded-xl bg-[#111722] border border-white/10 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <img src={chanLogo} alt="" className="w-6 h-6 object-contain" onError={(e) => ((e.target as HTMLElement).style.display = 'none')} />
                      <span className="font-bold text-white text-sm">{chanName}</span>
                    </div>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                      LIVE
                    </span>
                  </div>

                  <div className="p-3 rounded-lg bg-[#080B12] border border-white/5 space-y-1.5">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-slate-400">Now Playing:</span>
                      <span className="font-mono text-slate-500 text-[10px]">{startTime} – {endTime}</span>
                    </div>
                    <p className="text-xs font-semibold text-white">{progCurrent}</p>
                    <div className="w-full bg-white/10 h-1.5 rounded-full overflow-hidden mt-1">
                      <div className="bg-[#E5093A] h-full w-2/3" />
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
                    <span className="text-[11px] text-slate-500">Up Next:</span>
                    <span className="text-xs text-slate-300 font-medium truncate max-w-[220px]">{progNext}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* TAB 6: DEVICES MANAGEMENT */}
      {/* ==================================================== */}
      {activeTab === 'devices' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-2xl bg-[#111722] border border-white/10">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-purple-400 font-display">
                Household Concurrency Enforcement
              </span>
              <h2 className="text-lg font-bold text-white font-display mt-0.5">
                Active Member Devices & Revocation
              </h2>
              <p className="text-xs text-slate-400 mt-1 max-w-xl">
                Current limit: <strong>{slots.maxDevicesPerUser} concurrent devices</strong> per approved member account. Administrators can instantly revoke rogue or stale sessions.
              </p>
            </div>
            <div className="text-xs font-semibold text-slate-300 px-3 py-1.5 rounded-xl bg-white/5 border border-white/10 self-start sm:self-auto">
              Total Tracked: {devicesList.length} Devices
            </div>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-white/10 bg-[#111722]">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-[#080B12] text-slate-400 uppercase text-[10px] font-bold tracking-wider">
                <tr>
                  <th className="p-4">Member Name</th>
                  <th className="p-4">Device Name</th>
                  <th className="p-4">Device Type</th>
                  <th className="p-4">OS & Browser</th>
                  <th className="p-4">Last Active</th>
                  <th className="p-4">Session State</th>
                  <th className="p-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {devicesList.map((item) => (
                  <tr key={`${item.userId}-${item.device.id}`} className="hover:bg-white/5 transition-colors">
                    <td className="p-4 font-semibold text-white">
                      <div>{item.userName}</div>
                      <div className="text-[10px] text-slate-500 font-mono">{item.userEmail}</div>
                    </td>
                    <td className="p-4 text-white font-medium flex items-center gap-2">
                      {item.device.deviceType === 'desktop' ? <Laptop className="w-4 h-4 text-cyan-400" /> :
                       item.device.deviceType === 'smart_tv' ? <Tv className="w-4 h-4 text-purple-400" /> :
                       <Smartphone className="w-4 h-4 text-emerald-400" />}
                      <span>{item.device.name}</span>
                    </td>
                    <td className="p-4 capitalize text-slate-400">{item.device.deviceType}</td>
                    <td className="p-4 text-slate-400 text-[11px]">
                      {item.device.os} · {item.device.browser}
                    </td>
                    <td className="p-4 text-slate-300 font-mono text-[11px]">{item.device.lastActive}</td>
                    <td className="p-4">
                      {item.device.isCurrent ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-emerald-500/20 text-emerald-300">
                          Current Device
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-slate-700/30 text-slate-400">
                          Authorized
                        </span>
                      )}
                    </td>
                    <td className="p-4 text-right">
                      <button
                        onClick={() => handleRevokeDevice(item.userId, item.device.id)}
                        className="px-3 py-1 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/20 text-xs font-semibold transition-colors"
                      >
                        Revoke Device
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* TAB 7: WATCH HISTORY */}
      {/* ==================================================== */}
      {activeTab === 'history' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-2xl bg-[#111722] border border-white/10">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-400 font-display">
                Private Pilot Telemetry
              </span>
              <h2 className="text-lg font-bold text-white font-display mt-0.5">
                Household Watch History & Activity
              </h2>
              <p className="text-xs text-slate-400 mt-1 max-w-xl">
                Audited stream engagement across family members. Allows Continue Watching synchronization across authorized devices.
              </p>
            </div>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-white/10 bg-[#111722]">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-[#080B12] text-slate-400 uppercase text-[10px] font-bold tracking-wider">
                <tr>
                  <th className="p-4">Pilot Member</th>
                  <th className="p-4">Content Title</th>
                  <th className="p-4">Type</th>
                  <th className="p-4">Completion Progress</th>
                  <th className="p-4 text-right">Watched At</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {watchHistoryList.map((rec) => (
                  <tr key={rec.id} className="hover:bg-white/5 transition-colors">
                    <td className="p-4 font-semibold text-white">{rec.userName}</td>
                    <td className="p-4 font-medium text-white">{rec.contentTitle}</td>
                    <td className="p-4">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                        rec.contentType === 'channel' ? 'bg-purple-500/20 text-purple-300' : 'bg-cyan-500/20 text-cyan-300'
                      }`}>
                        {rec.contentType === 'channel' ? 'Live Channel' : 'Cinema Film'}
                      </span>
                    </td>
                    <td className="p-4 w-48">
                      <div className="flex items-center gap-2">
                        <div className="flex-1 bg-white/10 h-1.5 rounded-full overflow-hidden">
                          <div className="bg-[#E5093A] h-full" style={{ width: `${rec.progressPercentage}%` }} />
                        </div>
                        <span className="text-[10px] font-mono text-slate-400">{rec.progressPercentage}%</span>
                      </div>
                    </td>
                    <td className="p-4 text-right font-mono text-[11px] text-slate-400">
                      {new Date(rec.watchedAt).toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* TAB 8: SETTINGS & SECP ROADMAP */}
      {/* ==================================================== */}
      {activeTab === 'settings' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-[#111722] border border-white/10 space-y-6">
            <div className="border-b border-white/10 pb-4">
              <span className="text-[10px] font-bold uppercase tracking-wider text-rose-400 font-display">
                Pilot Configuration & Company Roadmap
              </span>
              <h2 className="text-lg font-bold text-white font-display mt-0.5">
                Private Pilot Mode & Capacity Limits
              </h2>
              <p className="text-xs text-slate-400 mt-1 max-w-2xl leading-relaxed">
                Configure internal limits for the closed family beta. After SECP company registration is completed, the architecture can seamlessly transition to commercial operations without rebuilding.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div className="p-4 rounded-xl bg-[#080B12] border border-white/5 space-y-2">
                <label className="text-slate-400 block font-bold text-[11px]">Private Mode Status</label>
                <div className="flex items-center gap-2">
                  <span className={`w-2.5 h-2.5 rounded-full ${privateMode ? 'bg-emerald-400' : 'bg-slate-500'}`} />
                  <span className="font-semibold text-white">{privateMode ? 'PRIVATE_MODE = true' : 'Public Access'}</span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Public customer registration is locked. Admin approval required.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-[#080B12] border border-white/5 space-y-2">
                <label className="text-slate-400 block font-bold text-[11px]">Max Private Users (Capacity)</label>
                <input
                  type="number"
                  min="3"
                  max="50"
                  value={maxPrivateUsers}
                  onChange={(e) => setMaxPrivateUsers(parseInt(e.target.value) || 5)}
                  className="w-full bg-[#111722] border border-white/10 rounded-xl px-3 py-2 text-white font-mono"
                />
                <p className="text-[11px] text-slate-400">Target pilot size: 3–5 trusted members.</p>
              </div>

              <div className="p-4 rounded-xl bg-[#080B12] border border-white/5 space-y-2">
                <label className="text-slate-400 block font-bold text-[11px]">Max Devices Per User</label>
                <input
                  type="number"
                  min="1"
                  max="10"
                  value={maxDevicesPerUser}
                  onChange={(e) => setMaxDevicesPerUser(parseInt(e.target.value) || 2)}
                  className="w-full bg-[#111722] border border-white/10 rounded-xl px-3 py-2 text-white font-mono"
                />
                <p className="text-[11px] text-slate-400">Concurrency cap for household devices.</p>
              </div>
            </div>

            <div className="flex items-center justify-end">
              <button
                onClick={handleSavePilotSettings}
                className="px-5 py-2.5 rounded-xl bg-[#E5093A] text-white text-xs font-semibold shadow-md crimson-glow-sm"
              >
                Save Pilot Configuration
              </button>
            </div>
          </div>

          {/* SECP Company Registration Status & Future Architecture */}
          <div className="p-6 rounded-2xl bg-[#111722] border border-white/10 space-y-4">
            <h3 className="text-sm font-bold text-white font-display">
              SECP Corporate Incorporation & Commercial Readiness
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed max-w-2xl">
              Commercial checkout, public subscription pricing, and reseller advertising are safely disabled during this private pilot. The payment provider abstraction and subscription models are preserved for activation once regulatory filings are finalized.
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="p-3 rounded-lg bg-[#080B12] border border-white/5">
                <span className="text-[10px] text-slate-500 block">COMMERCIAL_MODE</span>
                <span className="font-mono text-rose-400 font-bold">false (Disabled)</span>
              </div>
              <div className="p-3 rounded-lg bg-[#080B12] border border-white/5">
                <span className="text-[10px] text-slate-500 block">PUBLIC_REGISTRATION</span>
                <span className="font-mono text-rose-400 font-bold">false (Disabled)</span>
              </div>
              <div className="p-3 rounded-lg bg-[#080B12] border border-white/5">
                <span className="text-[10px] text-slate-500 block">PAYMENTS_ENABLED</span>
                <span className="font-mono text-rose-400 font-bold">false (Disabled)</span>
              </div>
              <div className="p-3 rounded-lg bg-[#080B12] border border-white/5">
                <span className="text-[10px] text-slate-500 block">SECP FILING STATUS</span>
                <span className="font-mono text-amber-400 font-bold">In Preparation</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* TAB 9: CINEMA RIGHTS & DMCA TAKEDOWNS */}
      {/* ==================================================== */}
      {activeTab === 'cinema' && (
        <div className="space-y-8">
          {/* Broadcaster Channels Management */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold text-white font-display">
                  Verified Broadcaster Channels
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Statutory public broadcasters and official open-license live streams.
                </p>
              </div>
              <button
                onClick={() => setShowAddChannel(true)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#E5093A] text-white text-xs font-semibold shadow-md"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Broadcaster</span>
              </button>
            </div>

            <div className="overflow-x-auto rounded-2xl border border-white/10 bg-[#111722]">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-[#080B12] text-slate-400 uppercase text-[10px] font-bold tracking-wider">
                  <tr>
                    <th className="p-4">Channel</th>
                    <th className="p-4">Category</th>
                    <th className="p-4">Provenance</th>
                    <th className="p-4">Status</th>
                    <th className="p-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {channels.map((chan) => (
                    <tr key={chan.id} className="hover:bg-white/5 transition-colors">
                      <td className="p-4 font-semibold text-white flex items-center gap-2">
                        <img src={chan.logo} alt="" referrerPolicy="no-referrer" className="w-5 h-5 object-contain" />
                        <span>{chan.channelName}</span>
                      </td>
                      <td className="p-4">{chan.category}</td>
                      <td className="p-4 font-mono text-[10px] text-cyan-400">{chan.rightsStatus}</td>
                      <td className="p-4">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                          chan.enabled ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-400'
                        }`}>
                          {chan.enabled ? 'Active' : 'Disabled'}
                        </span>
                      </td>
                      <td className="p-4 text-right">
                        <button
                          onClick={() => handleToggleChannel(chan.id, chan.enabled)}
                          className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors ${
                            chan.enabled ? 'bg-rose-500/20 text-rose-300' : 'bg-emerald-500/20 text-emerald-300'
                          }`}
                        >
                          {chan.enabled ? 'Disable' : 'Enable'}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Public Domain Cinema Films */}
          <div className="space-y-4">
            <h2 className="text-lg font-bold text-white font-display">
              Cinema Catalog & License Provenance
            </h2>
            <div className="overflow-x-auto rounded-2xl border border-white/10 bg-[#111722]">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-[#080B12] text-slate-400 uppercase text-[10px] font-bold tracking-wider">
                  <tr>
                    <th className="p-4">Title</th>
                    <th className="p-4">Year</th>
                    <th className="p-4">License Type</th>
                    <th className="p-4">State</th>
                    <th className="p-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {movies.map((mov) => (
                    <tr key={mov.id} className="hover:bg-white/5 transition-colors">
                      <td className="p-4 font-semibold text-white">{mov.title}</td>
                      <td className="p-4">{mov.year}</td>
                      <td className="p-4 text-slate-300">{mov.license}</td>
                      <td className="p-4">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                          mov.enabled ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-400'
                        }`}>
                          {mov.enabled ? 'Published' : 'Disabled'}
                        </span>
                      </td>
                      <td className="p-4 text-right">
                        <button
                          onClick={() => handleToggleMovie(mov.id, mov.enabled)}
                          className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors ${
                            mov.enabled ? 'bg-rose-500/20 text-rose-300' : 'bg-emerald-500/20 text-emerald-300'
                          }`}
                        >
                          {mov.enabled ? 'Disable' : 'Enable'}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* DMCA Takedown Queue */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold text-white font-display">
                  Copyright & DMCA Notice Review Queue
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Notice & Takedown statutory compliance workflow.
                </p>
              </div>
              <button
                onClick={() => onNavigate('takedown')}
                className="text-xs text-[#E5093A] hover:underline"
              >
                View Public Form
              </button>
            </div>

            <div className="space-y-3">
              {takedowns.map((ticket) => (
                <div key={ticket.id} className="p-4 rounded-xl bg-[#111722] border border-white/10 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <ShieldAlert className="w-4 h-4 text-amber-400" />
                      <span className="font-bold text-white text-xs">
                        Ticket #{ticket.id} — {ticket.contentTitle}
                      </span>
                    </div>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-amber-500/20 text-amber-300">
                      {ticket.status}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300">Claimant: {ticket.claimantName} ({ticket.claimantEmail})</p>
                  <p className="text-xs text-slate-400 italic">"{ticket.statement}"</p>
                  {ticket.status !== 'ACCEPTED_REMOVED' && (
                    <div className="flex items-center gap-2 pt-1">
                      <button
                        onClick={() => handleProcessTakedown(ticket.id, 'DISABLE_AND_ACCEPT')}
                        className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold"
                      >
                        Disable Content & Accept Takedown
                      </button>
                      <button
                        onClick={() => handleProcessTakedown(ticket.id, 'REJECT')}
                        className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-semibold"
                      >
                        Reject (Verified)
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Add Channel Modal */}
          {showAddChannel && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
              <div className="w-full max-w-md rounded-2xl bg-[#111722] border border-white/10 p-6 shadow-2xl">
                <h3 className="text-base font-bold text-white font-display mb-4">
                  Add Verified Broadcaster Stream
                </h3>
                <div className="space-y-3 text-xs mb-6">
                  <div>
                    <label className="text-slate-400 block mb-1">Channel Name</label>
                    <input
                      type="text"
                      value={newChanName}
                      onChange={(e) => setNewChanName(e.target.value)}
                      placeholder="e.g. NHK World English"
                      className="w-full bg-[#080B12] border border-white/10 rounded-xl px-3 py-2 text-white"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-1">Direct Stream URL (.m3u8)</label>
                    <input
                      type="text"
                      value={newChanStream}
                      onChange={(e) => setNewChanStream(e.target.value)}
                      placeholder="https://.../index.m3u8"
                      className="w-full bg-[#080B12] border border-white/10 rounded-xl px-3 py-2 text-white font-mono text-[11px]"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-1">Source Name</label>
                    <input
                      type="text"
                      value={newChanSource}
                      onChange={(e) => setNewChanSource(e.target.value)}
                      placeholder="e.g. Official Public Web Feed"
                      className="w-full bg-[#080B12] border border-white/10 rounded-xl px-3 py-2 text-white"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-1">Category</label>
                    <select
                      value={newChanCategory}
                      onChange={(e) => setNewChanCategory(e.target.value as any)}
                      className="w-full bg-[#080B12] border border-white/10 rounded-xl px-3 py-2 text-white"
                    >
                      <option value="News">News</option>
                      <option value="Science & Tech">Science & Tech</option>
                      <option value="Sports">Sports</option>
                      <option value="Culture">Culture</option>
                    </select>
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2">
                  <button
                    onClick={() => setShowAddChannel(false)}
                    className="px-4 py-2 rounded-xl text-slate-400 hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleAddChannel}
                    className="px-5 py-2 rounded-xl bg-[#E5093A] text-white font-semibold"
                  >
                    Save & Activate
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ==================================================== */}
      {/* TAB 10: AUDIT LOGS */}
      {/* ==================================================== */}
      {activeTab === 'logs' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-[#111722] border border-white/10">
            <h2 className="text-lg font-bold text-white font-display mb-1">
              System Administration Audit Trail
            </h2>
            <p className="text-xs text-slate-400 mb-4">
              Real-time audit records of all administrative actions, takedown decisions, and member status transitions.
            </p>
            <div className="space-y-2 font-mono text-[11px] max-h-96 overflow-y-auto">
              {adminLogs.map((log) => (
                <div key={log.id} className="p-2.5 rounded-lg bg-[#080B12] border border-white/5 flex items-center justify-between">
                  <span className="text-[#E5093A] font-bold">{log.action}</span>
                  <span className="text-slate-300 flex-1 mx-3 truncate">{log.details}</span>
                  <span className="text-slate-500 text-[10px]">{new Date(log.timestamp).toLocaleString()}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Star IPTV Diagnostic Logs */}
          {iptvLogs.length > 0 && (
            <div className="p-6 rounded-2xl bg-[#111722] border border-white/10">
              <h3 className="text-sm font-bold text-white font-display mb-2">
                Star IPTV Diagnostic Event Log
              </h3>
              <div className="space-y-2 font-mono text-[11px] max-h-60 overflow-y-auto">
                {iptvLogs.map((log) => (
                  <div key={log.id} className="p-2 rounded-lg bg-[#080B12] border border-white/5 flex items-center justify-between">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      log.level === 'error' ? 'bg-rose-500/20 text-rose-300' : 'bg-cyan-500/20 text-cyan-300'
                    }`}>
                      {log.action}
                    </span>
                    <span className="text-slate-300 flex-1 mx-3 truncate">{log.message}</span>
                    <span className="text-slate-500 text-[10px]">{new Date(log.timestamp).toLocaleTimeString()}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
