import React from 'react';
import type { Channel, Movie, WatchProgress } from '../types/index.js';
import { HeroBanner } from '../components/common/HeroBanner.js';
import { ContentRail } from '../components/common/ContentRail.js';
import { MediaCard } from '../components/common/MediaCard.js';
import { ChannelCard } from '../components/common/ChannelCard.js';
import { useWatchlist } from '../context/WatchlistContext.js';
import { Sparkles, Heart } from 'lucide-react';

interface HomePageProps {
  movies: Movie[];
  channels: Channel[];
  continueWatching: WatchProgress[];
  onPlayMovie: (movie: Movie, mode?: 'full' | 'trailer') => void;
  onPlayChannel: (channel: Channel) => void;
  onOpenDetails: (movie: Movie) => void;
  onNavigate: (tab: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  movies,
  channels,
  continueWatching,
  onPlayMovie,
  onPlayChannel,
  onOpenDetails,
  onNavigate,
}) => {
  const { watchlistIds } = useWatchlist();
  const heroMovie = movies.find((m) => m.featured) || movies[0];
  const publicDomainMovies = movies.filter((m) => m.rightsStatus === 'PUBLIC_DOMAIN');
  const openLicenseMovies = movies.filter((m) => m.rightsStatus === 'OPEN_LICENSE');
  const liveChannels = channels.filter((c) => c.enabled);
  const favoriteMovies = movies.filter((m) => watchlistIds.has(m.id));
  const favoriteChannels = channels.filter((c) => watchlistIds.has(c.id));

  return (
    <div className="min-h-screen pb-16">
      {/* Cinematic Hero */}
      {heroMovie && (
        <HeroBanner
          movie={heroMovie}
          onPlay={onPlayMovie}
          onOpenDetails={onOpenDetails}
        />
      )}

      {/* Continue Watching Rail (Shown when user has watch progress) */}
      {continueWatching.length > 0 && (
        <ContentRail
          title="Continue Watching"
          subtitle="Resume playback where you left off"
          onViewAll={() => onNavigate('my-list')}
        >
          {continueWatching.map((item) => {
            const matchedMovie = movies.find((m) => m.id === item.contentId);
            const matchedChannel = channels.find((c) => c.id === item.contentId);

            if (matchedChannel) {
              return (
                <ChannelCard
                  key={item.contentId}
                  channel={matchedChannel}
                  onPlay={onPlayChannel}
                />
              );
            }

            if (matchedMovie) {
              return (
                <MediaCard
                  key={item.contentId}
                  movie={matchedMovie}
                  progress={item}
                  onPlay={onPlayMovie}
                  onOpenDetails={onOpenDetails}
                />
              );
            }

            return null;
          })}
        </ContentRail>
      )}

      {/* My List & Favorites (Requirement 9) */}
      {(favoriteMovies.length > 0 || favoriteChannels.length > 0) && (
        <ContentRail
          title="My List & Favorites"
          subtitle="Your personal saved channels and curated films"
          onViewAll={() => onNavigate('my-list')}
        >
          {favoriteChannels.map((channel) => (
            <ChannelCard
              key={channel.id}
              channel={channel}
              onPlay={onPlayChannel}
            />
          ))}
          {favoriteMovies.map((movie) => (
            <MediaCard
              key={movie.id}
              movie={movie}
              onPlay={onPlayMovie}
              onOpenDetails={onOpenDetails}
              aspectRatio="poster"
            />
          ))}
        </ContentRail>
      )}

      {/* Live Now (Verified Public Broadcasts) */}
      <ContentRail
        title="Live International Broadcasts"
        subtitle="Free-to-air public service channels streamed without paywalls"
        onViewAll={() => onNavigate('live-tv')}
      >
        {liveChannels.map((channel) => (
          <ChannelCard
            key={channel.id}
            channel={channel}
            onPlay={onPlayChannel}
          />
        ))}
      </ContentRail>

      {/* Public Domain Cinema Classics */}
      <ContentRail
        title="Public Domain Cinema Masterpieces"
        subtitle="Digitally restored classic films with verified public rights"
        onViewAll={() => onNavigate('free-cinema')}
      >
        {publicDomainMovies.map((movie) => (
          <MediaCard
            key={movie.id}
            movie={movie}
            onPlay={onPlayMovie}
            onOpenDetails={onOpenDetails}
            aspectRatio="poster"
          />
        ))}
      </ContentRail>

      {/* Star IPTV Private Pilot Showcase Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 my-8 md:my-12">
        <div className="relative rounded-2xl overflow-hidden bg-gradient-to-r from-[#111722] via-[#151D29] to-[#0A0E17] border border-white/10 p-6 md:p-10 shadow-2xl">
          {/* Subtle glow circle */}
          <div className="absolute top-0 right-0 w-80 h-80 bg-[#E5093A]/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 max-w-2xl">
            <div className="flex items-center gap-2 mb-3">
              <span className="flex items-center gap-1.5 text-xs font-semibold text-[#E5093A] tracking-wider uppercase">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Authorized Star IPTV Reseller Testing Gateway</span>
              </span>
            </div>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-white font-display tracking-tight leading-tight mb-3">
              Private Household Streaming Pilot
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-6">
              Private testing of authorized Star IPTV high-bitrate live feeds, electronic program guides (EPG),
              and multi-screen household concurrency. All sensitive streaming credentials are kept strictly inside secure backend vaults.
            </p>
            <div className="flex flex-wrap items-center gap-3">
              <button
                onClick={() => onNavigate('pricing')}
                className="px-6 py-3 rounded-xl bg-[#E5093A] hover:bg-[#B90732] text-white text-xs sm:text-sm font-semibold shadow-lg crimson-glow transition-all active:scale-95"
              >
                Private Access Overview
              </button>
              <button
                onClick={() => onNavigate('live-tv')}
                className="flex items-center gap-1.5 px-4 py-3 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs sm:text-sm font-medium border border-white/10 transition-colors"
              >
                <span>Browse Live TV Channels</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Open Source / Creative Commons Films */}
      <ContentRail
        title="Open-Source & Creative Commons Cinema"
        subtitle="Independent computer-generated cinema and Creative Commons productions"
        onViewAll={() => onNavigate('free-cinema')}
      >
        {openLicenseMovies.map((movie) => (
          <MediaCard
            key={movie.id}
            movie={movie}
            onPlay={onPlayMovie}
            onOpenDetails={onOpenDetails}
          />
        ))}
      </ContentRail>

      {/* All Cinema Collections */}
      <ContentRail
        title="Trending Cinematic Releases"
        subtitle="Popular full features and verified promotional festival previews"
        onViewAll={() => onNavigate('movies')}
      >
        {movies.map((movie) => (
          <MediaCard
            key={movie.id}
            movie={movie}
            onPlay={onPlayMovie}
            onOpenDetails={onOpenDetails}
          />
        ))}
      </ContentRail>
    </div>
  );
};
