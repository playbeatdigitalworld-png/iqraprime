/**
 * Aether Stream Frontend API Client
 */

import type {
  AdminDeviceRecord,
  AdminStats,
  AdminWatchHistoryRecord,
  Channel,
  DeviceInfo,
  IPTVLiveCategory,
  M3UChannel,
  MemberAccount,
  Movie,
  PilotSettings,
  StarIPTVLog,
  StarIPTVPackage,
  StarIPTVVaultConfig,
  Subscription,
  TakedownRequest,
  User,
  WatchProgress,
} from '../types/index.js';

const BASE_URL = '/api';

export const api = {
  // Auth
  async login(email: string, password: string) {
    const res = await fetch(`${BASE_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      throw new Error(data.error || 'Failed to login');
    }
    return res.json() as Promise<{ success: boolean; user: User; subscription?: Subscription; token: string }>;
  },

  async register(name: string, email: string, password: string) {
    const res = await fetch(`${BASE_URL}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password }),
    });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      throw new Error(data.error || 'Failed to register');
    }
    return res.json() as Promise<{ success: boolean; user: User; subscription: Subscription; token: string }>;
  },

  async getMe(token?: string) {
    const res = await fetch(`${BASE_URL}/auth/me`, {
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    });
    if (!res.ok) throw new Error('Unauthorized');
    return res.json() as Promise<{ user: User; subscription: Subscription }>;
  },

  // Content
  async getChannels() {
    const res = await fetch(`${BASE_URL}/content/channels`);
    if (!res.ok) throw new Error('Failed to load channels');
    const data = await res.json();
    return data.channels as Channel[];
  },

  async getMovies() {
    const res = await fetch(`${BASE_URL}/content/movies`);
    if (!res.ok) throw new Error('Failed to load movies');
    const data = await res.json();
    return data.movies as Movie[];
  },

  async getContinueWatching(userId?: string) {
    const res = await fetch(`${BASE_URL}/content/continue-watching?userId=${userId || ''}`);
    if (!res.ok) return [];
    const data = await res.json();
    return data.continueWatching as WatchProgress[];
  },

  async recordProgress(data: { contentId: string; contentType?: 'movie' | 'channel'; positionSeconds: number; durationSeconds: number; userId?: string }) {
    await fetch(`${BASE_URL}/content/progress`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    }).catch(() => {});
  },

  async getWatchlist(userId?: string) {
    const res = await fetch(`${BASE_URL}/content/watchlist?userId=${userId || ''}`);
    if (!res.ok) return [];
    const data = await res.json();
    return data.watchlist as Array<{ type: 'channel' | 'movie'; data: Channel | Movie }>;
  },

  async toggleWatchlist(contentId: string, userId?: string) {
    const res = await fetch(`${BASE_URL}/content/watchlist/toggle`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ contentId, userId }),
    });
    return res.json() as Promise<{ success: boolean; inList: boolean; contentId: string }>;
  },

  // Subscriptions & Plans
  async getPlans() {
    const res = await fetch(`${BASE_URL}/subscriptions/plans`);
    return res.json();
  },

  async getMySubscription(userId?: string) {
    const res = await fetch(`${BASE_URL}/subscriptions/my-subscription?userId=${userId || ''}`);
    return res.json();
  },

  async orderPlan(payload: { planId: string; packageId?: string; paymentMethod: string; name?: string; email?: string; userId?: string }) {
    const res = await fetch(`${BASE_URL}/subscriptions/order`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    return res.json();
  },

  // Pilot Settings & Member Management
  async getPilotSettings() {
    const res = await fetch(`${BASE_URL}/pilot/settings`);
    return res.json() as Promise<{ settings: PilotSettings }>;
  },

  async updatePilotSettings(payload: Partial<PilotSettings>) {
    const res = await fetch(`${BASE_URL}/pilot/settings`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    return res.json() as Promise<{ success: boolean; settings: PilotSettings }>;
  },

  async getMembers() {
    const res = await fetch(`${BASE_URL}/admin/members`);
    return res.json() as Promise<{
      members: MemberAccount[];
      slots: { total: number; current: number; active: number; remaining: number; maxDevicesPerUser: number };
    }>;
  },

  async createMember(name: string, email: string, password: string) {
    const res = await fetch(`${BASE_URL}/admin/members/create`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to create member');
    }
    return res.json() as Promise<{ success: boolean; member: MemberAccount }>;
  },

  async toggleMember(id: string) {
    const res = await fetch(`${BASE_URL}/admin/members/${id}/toggle`, { method: 'POST' });
    return res.json() as Promise<{ success: boolean; status: 'active' | 'disabled' }>;
  },

  async deleteMember(id: string) {
    const res = await fetch(`${BASE_URL}/admin/members/${id}`, { method: 'DELETE' });
    return res.json() as Promise<{ success: boolean; message: string }>;
  },

  async resetMemberPassword(id: string, password: string) {
    const res = await fetch(`${BASE_URL}/admin/members/${id}/reset-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password }),
    });
    return res.json();
  },

  async revokeDevice(userId: string, deviceId: string) {
    const res = await fetch(`${BASE_URL}/devices/revoke`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, deviceId }),
    });
    return res.json() as Promise<{ success: boolean; devices: DeviceInfo[]; message: string }>;
  },

  // Star IPTV Credentials Vault & M3U / EPG
  async getStarIPTVConfig() {
    const res = await fetch(`${BASE_URL}/iptv/config`);
    return res.json() as Promise<{
      config: StarIPTVVaultConfig;
      logs: StarIPTVLog[];
    }>;
  },

  async updateStarIPTVConfig(payload: {
    providerName?: string;
    serverUrl?: string;
    username?: string;
    password?: string;
    m3uUrl?: string;
    epgUrl?: string;
    apiUrl?: string;
    apiKey?: string;
    resellerId?: string;
  }) {
    const res = await fetch(`${BASE_URL}/iptv/config`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    return res.json();
  },

  async testStarIPTVConnection() {
    const res = await fetch(`${BASE_URL}/iptv/test-connection`, { method: 'POST' });
    return res.json() as Promise<{ status: string; statusCode?: number; latencyMs?: number; message: string; timestamp: string }>;
  },

  async testM3U(url?: string) {
    const res = await fetch(`${BASE_URL}/iptv/test-m3u`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url }),
    });
    return res.json() as Promise<{ status: string; valid: boolean; channelCount?: number; latencyMs?: number; message: string }>;
  },

  async testEPG(url?: string) {
    const res = await fetch(`${BASE_URL}/iptv/test-epg`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url }),
    });
    return res.json() as Promise<{ status: string; valid: boolean; latencyMs?: number; message: string }>;
  },

  async importM3U(url?: string) {
    const res = await fetch(`${BASE_URL}/iptv/import-m3u`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url }),
    });
    return res.json() as Promise<{ success: boolean; channels: M3UChannel[]; count: number; message: string }>;
  },

  async getM3UChannels() {
    const res = await fetch(`${BASE_URL}/iptv/m3u-channels`);
    return res.json() as Promise<{ channels: M3UChannel[]; total: number }>;
  },

  async toggleM3UChannel(id: string, enabled?: boolean) {
    const res = await fetch(`${BASE_URL}/iptv/m3u-channels/${id}/toggle`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ enabled }),
    });
    return res.json();
  },

  async bulkToggleM3UChannels(enabled: boolean, group?: string) {
    const res = await fetch(`${BASE_URL}/iptv/m3u-channels/bulk`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ enabled, group }),
    });
    return res.json() as Promise<{ success: boolean; count: number }>;
  },

  async getIPTVCategories() {
    const res = await fetch(`${BASE_URL}/iptv/categories`);
    return res.json() as Promise<{ categories: IPTVLiveCategory[]; total: number }>;
  },

  async importIPTVCategory(categoryId: string) {
    const res = await fetch(`${BASE_URL}/iptv/import-category`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ categoryId }),
    });
    return res.json() as Promise<{ success: boolean; count: number; categoryName: string; channels: M3UChannel[] }>;
  },

  async getStarIPTVPackages() {
    const res = await fetch(`${BASE_URL}/iptv/packages`);
    return res.json() as Promise<{ packages: StarIPTVPackage[]; source: string; note?: string }>;
  },

  // Admin
  async getAdminStats() {
    const res = await fetch(`${BASE_URL}/admin/stats`);
    return res.json() as Promise<{ stats: AdminStats; logs: Array<{ id: string; timestamp: string; action: string; details: string }> }>;
  },

  async getAdminChannels() {
    const res = await fetch(`${BASE_URL}/admin/channels`);
    const data = await res.json();
    return data.channels as Channel[];
  },

  async toggleChannel(channelId: string, enabled?: boolean) {
    const res = await fetch(`${BASE_URL}/admin/channels/toggle`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ channelId, enabled }),
    });
    return res.json();
  },

  async getAdminMovies() {
    const res = await fetch(`${BASE_URL}/admin/movies`);
    const data = await res.json();
    return data.movies as Movie[];
  },

  async toggleMovie(movieId: string, enabled?: boolean) {
    const res = await fetch(`${BASE_URL}/admin/movies/toggle`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ movieId, enabled }),
    });
    return res.json();
  },

  async getTakedowns() {
    const res = await fetch(`${BASE_URL}/admin/takedowns`);
    const data = await res.json();
    return data.takedowns as TakedownRequest[];
  },

  async processTakedown(id: string, action: 'DISABLE_AND_ACCEPT' | 'REJECT' | 'UNDER_REVIEW', notes?: string) {
    const res = await fetch(`${BASE_URL}/admin/takedowns/${id}/action`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, notes }),
    });
    return res.json();
  },

  async getAdminDevices() {
    const res = await fetch(`${BASE_URL}/admin/devices`);
    return res.json() as Promise<{ devices: AdminDeviceRecord[]; total: number }>;
  },

  async revokeAdminDevice(userId: string, deviceId: string) {
    const res = await fetch(`${BASE_URL}/devices/revoke`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, deviceId }),
    });
    return res.json();
  },

  async getAdminWatchHistory() {
    const res = await fetch(`${BASE_URL}/admin/watch-history`);
    return res.json() as Promise<{ history: AdminWatchHistoryRecord[]; total: number }>;
  },

  // Public DMCA / Takedown Report
  async submitTakedownReport(payload: {
    contentId?: string;
    contentTitle?: string;
    claimantName: string;
    claimantEmail: string;
    copyrightOwner?: string;
    allegedInfringementUrl?: string;
    statement: string;
  }) {
    const res = await fetch(`${BASE_URL}/takedown/submit`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to submit report');
    }
    return res.json() as Promise<{ success: boolean; ticketNumber: string; message: string }>;
  },
};
